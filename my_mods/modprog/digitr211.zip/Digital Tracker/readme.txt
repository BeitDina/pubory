05/15/ 2000

Digital Tracker 2.11 for BeOS by SOFTJEE.

Simply launch the "digital tracker " program to try this new version. More informations in HTML format in the folder "doc_demo" or from the software.

Go to our WEB  site : www.digital-tracker.com or www.softjee.com
