@echo off
del *.obj
del *.res
c:\Masm32\BIN\rc.exe /v rsrc.rc
c:\Masm32\BIN\cvtres.exe /machine:ix86 rsrc.res
c:\Masm32\BIN\ml.exe /c /coff player.asm
c:\Masm32\BIN\link.exe /SUBSYSTEM:WINDOWS player.obj rsrc.obj
