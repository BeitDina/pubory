; #########################################################################
; Simple BASS Player in MASM32 
; by TBD
;
; MASM32 package (c) Steve 'Hutch' Hutchesson http://www.movsd.com
; BASS engine (c) Ian Luck  http://www.un4seen.com/
; ModPlay 2005 (c) OryNider http://pubory.3x.ro
;
;  See modplay.txt for verion history and more.
; #########################################################################

      .486                      ; create 32 bit code
      .model flat, stdcall      ; 32 bit memory model
      option casemap :none      ; case sensitive

;     include files
;     ~~~~~~~~~~~~~
      include c:\Masm32\include\windows.inc
      include c:\Masm32\include\masm32.inc
      include c:\Masm32\include\gdi32.inc
      include c:\Masm32\include\user32.inc
      include c:\Masm32\include\kernel32.inc
      include c:\Masm32\include\shell32.inc
      include c:\Masm32\include\Comctl32.inc
      include c:\Masm32\include\comdlg32.inc
      include c:\Masm32\include\winmm.inc
      include c:\masm32\include\shlwapi.inc
      include c:\MASM32\include\oleaut32.inc 

      include bass.inc


;     libraries
;     ~~~~~~~~~
      includelib c:\Masm32\lib\masm32.lib
      includelib c:\Masm32\lib\gdi32.lib
      includelib c:\Masm32\lib\user32.lib
      includelib c:\Masm32\lib\kernel32.lib
      includelib c:\Masm32\lib\shell32.lib
      includelib c:\Masm32\lib\Comctl32.lib
      includelib c:\Masm32\lib\comdlg32.lib
      includelib c:\Masm32\lib\winmm.lib
      includelib c:\masm32\lib\shlwapi.lib
      includelib c:\MASM32\LIB\oleaut32.lib

      
      includelib bass.lib

; #########################################################################

; ----------------------------------------------------------------------
; Prototypes are used in conjunction with the MASM "invoke" syntax for
; checking the number and size of parameters passed to a procedure. This
; improves the reliability of code that is written where errors in
; parameters are caught and displayed at assembly time.
; ----------------------------------------------------------------------
      ;=================
      ; Local prototypes
      ;=================   

      WinMain          PROTO :DWORD,:DWORD,:DWORD,:DWORD
      WndProc          PROTO :DWORD,:DWORD,:DWORD,:DWORD
      TopXY            PROTO :DWORD,:DWORD
      GetFileName      PROTO :DWORD, :DWORD, :DWORD
      Do_Status        PROTO :DWORD
      RegisterWinClass PROTO :DWORD,:DWORD,:DWORD,:DWORD,:DWORD
      MsgLoop          PROTO
      Main             PROTO
      Level            PROTO :DWORD,:DWORD,:DWORD,:DWORD,:DWORD
      Do_ToolBar       PROTO :DWORD
      SetBmpColor      PROTO :DWORD
      ListBox 	       PROTO :DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD
      ListProc 	       PROTO :DWORD,:DWORD,:DWORD,:DWORD
      PushButton       PROTO :DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD
      Frame3D 	       PROTO :DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD
      Paint_Proc       PROTO :DWORD,:DWORD
      FillBuffer     PROTO :DWORD,:DWORD,:BYTE
      EditControl    PROTO :DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD
      hEditProc      PROTO :DWORD,:DWORD,:DWORD,:DWORD
      Select_All     PROTO :DWORD
      TextFind       PROTO :DWORD,:DWORD
      SearchProc     PROTO :DWORD,:DWORD,:DWORD,:DWORD
      CallSearchDlg  PROTO
      StreamFileOut  PROTO :DWORD,:DWORD
      StreamFileIn   PROTO :DWORD,:DWORD
      ofCallBack     PROTO :DWORD,:DWORD,:DWORD,:DWORD
      sfCallBack     PROTO :DWORD,:DWORD,:DWORD,:DWORD
      Confirmation   PROTO :DWORD
      MergeFile      PROTO :DWORD
      GetFileName    PROTO :DWORD, :DWORD, :DWORD
      SaveFileName   PROTO :DWORD, :DWORD, :DWORD
      TypeLib	     PROTO :DWORD,:DWORD,:BYTE
  
      wsprintfA PROTO C :DWORD,:VARARG
      wsprintf equ <wsprintfA>

      ;=============
      ; Local macros
      ;=============

 ; ------------------------------------------------------------------------
; MACROS are a method of expanding text at assembly time. This allows the
; programmer a tidy and convenient way of using COMMON blocks of code with
; the capacity to use DIFFERENT parameters in each block.
; ------------------------------------------------------------------------

      ; 1. szText
      ; A macro to insert TEXT into the code section for convenient and 
      ; more intuitive coding of functions that use byte data as text.

      szText MACRO Name, Text:VARARG
        LOCAL lbl
          jmp lbl
            Name db Text,0
          lbl:
        ENDM

      ; 2. m2m
      ; There is no mnemonic to copy from one memory location to another,
      ; this macro saves repeated coding of this process and is easier to
      ; read in complex code.

      m2m MACRO M1, M2
        push M2
        pop  M1
      ENDM

      ; 3. return
      ; Every procedure MUST have a "ret" to return the instruction
      ; pointer EIP back to the next instruction after the call that
      ; branched to it. This macro puts a return value in eax and
      ; makes the "ret" instruction on one line. It is mainly used
      ; for clear coding in complex conditionals in large branching
      ; code such as the WndProc procedure.

      return MACRO arg
        mov eax, arg
        ret
      ENDM

      DisplayMenu MACRO handl, IDnum
        invoke LoadMenu,hInstance,IDnum
        invoke SetMenu,handl,eax
      ENDM

      DisplayWindow MACRO handl, ShowStyle
        invoke ShowWindow,handl, ShowStyle
        invoke UpdateWindow,handl
      ENDM

      ; ----------------------------------------
      ; qinvoke - macro for functions with QWORD
      ; ----------------------------------------
      
      qinvoke MACRO function:REQ,p1,p2,p3,p4,p5,p6,p7,p8
                                 
         push 0
      	 FOR arg,<p8,p7,p6,p5,p4,p3,p2,p1>
      	  IFNB <arg>         ; if not blank
                push arg     ; push parameter
      	  ENDIF
         ENDM
         call function       
      ENDM

      ; ---------------------------
      ; macros for creating toolbar
      ; ---------------------------


      TBextraData MACRO
        mov tbb.fsState,   TBSTATE_ENABLED
        mov tbb.dwData,    0
        mov tbb.iString,   0
      ENDM

      ; ------------------------------

      TBbutton MACRO bID, cID, bStyle
        mov tbb.iBitmap,   bID  ;; button  ID number
        mov tbb.idCommand, cID  ;; command ID number
        mov tbb.fsStyle,   bStyle 
        invoke SendMessage,hToolBar,TB_ADDBUTTONS,1,ADDR tbb
      ENDM

      ; ------------------------------

      TBblank MACRO
        mov tbb.iBitmap,   0
        mov tbb.idCommand, 0
        mov tbb.fsStyle,   TBSTYLE_SEP
        invoke SendMessage,hToolBar,TB_ADDBUTTONS,1,ADDR tbb
      ENDM

      stralloc MACRO ln
        invoke SysAllocStringByteLen,0,ln
      ENDM

      strfree MACRO strhandle
        invoke SysFreeString,strhandle
      ENDM


      ; ------------------------------

      Create_Tool_Bar MACRO Wd, Ht

        szText tbClass,"ToolbarWindow32"

        invoke CreateWindowEx,0,
                              ADDR tbClass,
                              ADDR tbClass,
                              WS_CHILD or WS_VISIBLE or TBSTYLE_FLAT,
                              0,0,500,20,
                              hWin,NULL,
                              hInstance,NULL

        mov hToolBar, eax
    
        invoke SendMessage,hToolBar,TB_BUTTONSTRUCTSIZE,sizeof TBBUTTON,0
    
        ; ---------------------------------------
        ; Put width & height of bitmap into DWORD
        ; ---------------------------------------
        mov  ecx,Wd  ;; loword = bitmap Width
        mov  eax,Ht  ;; hiword = bitmap Height
        shl  eax,16
        mov  ax, cx

        mov bSize, eax
    
        invoke SendMessage,hToolBar,TB_SETBITMAPSIZE,0,bSize
    
        invoke SetBmpColor,hTbBmp
        mov hTbBmp,eax
    
        mov tbab.hInst, 0
        m2m tbab.nID,   hTbBmp
        invoke SendMessage,hToolBar,TB_ADDBITMAP,12,ADDR tbab
    
        invoke SendMessage,hToolBar,TB_SETBUTTONSIZE,0,bSize
      ENDM


    ; --------------------------------------------
    ; equates to use directly in the message loop
    ; --------------------------------------------
        m_hWnd   	equ <msg.hwnd>
        m_Msg    	equ <msg.message>
        m_wParam 	equ <msg.wParam>
        m_lParam 	equ <msg.lParam>
      	modplay  	equ <anyfile>
    ; -----------------------------------
    ; equates for tray icon
    ; -----------------------------------
	WM_SHELLNOTIFY	equ WM_USER+5
	IDI_TRAY	equ 0
	IDM_RESTORE	equ 2001
	IDM_EXIT	equ 2002
    ; -----------------------------------
    ; Select right click menu popup here
    ; -----------------------------------
      menu_popup equ 0  ; 0 = File, 1 = Edit etc ....

    ; --------------------------
    ; Select either system font
    ; --------------------------
      edit_font equ <SYSTEM_FIXED_FONT>
      ; edit_font equ <ANSI_FIXED_FONT>


; #########################################################################

; ------------------------------------------------------------------------
; This is the INITIALISED data section meaning that data declared here has
; an initial value. You can also use an UNINIALISED section if you need
; data of that type [ .data? ]. Note that they are different and occur in
; different sections.
; ------------------------------------------------------------------------
.data
DlgName		db "MyDialog",0
AppName		db "Module Player",0
AppName2	db "Module Player # will not own my brain!",0
Copyright	db "Module Player - Copyright � TBD 2oo2, � OryNider 2oo5",10,13,"orynider@rdslink.ro",0
Nonce		db "File cannot be located.",0
HelpFile	db "modplay.txt",0
TrayClassName	db "TrayIconWinClass",0
RestoreString	db "&Restore",0
ExitString	db "E&xit Program",0
; data 
szClassName    db "BASS_Player",0
szDisplayName  db "Module Player",0
szAboutText    db "Module Player",13,10,"Copyright � OryNider 2005",0
szFormatString db "%03u:%03u | %s",0
szOpen         db "Open A File",0
;szFiles       db "All Supported (MO3, MOD, S3M, IT, XM, MTM, UMX)",0,"*.mo3;*.mod;*.s3m;*.it;*.xm;*.mtm;*.umx",0     
szFiles        db "MO3, MOD, S3M, IT, XM, MTM, UMX Modules",0,"*.mo3;*.mod;*.s3m;*.it;*.xm;*.mtm;*.umx",0     
               db "FastTracker, Protracker, Soundtracker (*.mod)",0,"*.mod",0
               db "Impulse Tracker (*.it)",0,"*.it",0
               db "eXtended Modules (*.xm)",0,"*.xm",0
               db "Compressed Modules (*.mo3)",0,"*.mo3",0
               db "Screamtracker 2.x (*.stm)",0,"*.stm",0
               db "Screamtracker 3.x (*.s3m)",0,"*.s3m",0
               db "MultiTracker (*.mtm)",0,"*.mtm",0
               db "Ultra Tracker 1.x  (*.ult)",0,"*.ult",0
               db "Unreal Game Modules  (*.umx)",0,"*.umx",0
               db "Composer 669, Extended 669, UNIS 669 (*.669)",0,"*.669",0
               db "Farandole Compozer 1.x (*.far)",0,"*.far",0
               db "Asylum / DSMI modules (*.amf)",0,"*.amf",0
               db "Velvet Studio AMS 1.x modules (*.ams)",0,"*.ams",0
               db "DigiBooster Pro modules (*.dbm)",0,"*.dbm",0
               db "DSIK internal format modules (*.dsm)",0,"*.dsm",0
               db "OctaMed modules (*.med)",0,"*.med",0
               db "DigiTracker 1.x modules (*.mdl)",0,"*.mdl",0
               db "NoiseTracker modules (*.nst)",0,"*.nst",0
               db "OktaLyser modules (*.okt)",0,"*.okt",0
               db "PolyTracker modules (*.ptm)",0,"*.ptm",0
               db "Grave Composer modules (*.wow)",0,"*.wow",0
               db "Zipped modules (*.mdz, *.s3z, *.xmz, *.itz ...)",0,"*.moz;*.mdz;*.s3z;*.xmz;*.itz;*.xmz;*.mtz;*.umz;*.stz;*.utz;*.66z;*.faz;*.amz;*.dbz;*.dsz;*.mez;*.nsz;*.okz;*.ptz;*.woz",0
               db "All Files (*.*)",0,"*.*",0,0
FileEx         db ".mo3",0,".mod",0,".s3m",0,".it",0,".xm",0,".mtm",0,".umx",0,".???",0
FixSize	       db "Original File Size is 17,920 Kb",0
Message	       db "Hello :))",0
max            dword	45

  .data?
      hInstance     dd ?
      hIcon         dd ?
      hIcon16       dd ?
      hIcon32       dd ?
      hIconW        dd ?
      CommandLine   dd ?
      hCursor       dd ?
      hWnd          dd ?
      hList         dd ?
      lpfnListProc  dd ?
      ModHandle     dd ?
      ModName       dd ?
      MusicFile     dd ?         
      hStatus       dd ?
      hTbBmp        dd ?
      hToolBar      dd ?
      SurroundOn    dd ?
      timer         dd ?
      hWinLevel     dd ?
      specdc        dd ?
      specbmp       dd ?
      specbuf       dd ?
      hRichEd       dd ?
      hToolTips     dd ?
      hCheck1       dd ?
      hCheck2       dd ?
      TextLen       dd ?
      CaseFlag      dd ?
      WholeWord     dd ?
      CtrlFlag      dd ?
      hMnu          dd ?
      hPopupMenu    dd ?
      szFileName2   db 260 dup(?)
      szFileNames   db 260 dup(?)
      Untitled      db ?
      titLen        dword ?
      fileno        dd    ?        ; file type number from list
      filept        dword ?        ; pointer into file type list
      SearchText    db 128 dup(?)
      titleBuffer   db 128 dup(?)  ; used to get title from szFileName


      VIS_WIDTH     = 56
      VIS_HEIGHT    = 9
      note	    NOTIFYICONDATA <>
      ofn           OPENFILENAME <>  ; structure
      bmp           BITMAPINFO <>
      
; #########################################################################

; ------------------------------------------------------------------------
; This is the start of the code section where executable code begins. This
; section ending with the ExitProcess() API function call is the only
; GLOBAL section of code and it provides access to the WinMain function
; with the necessary parameters, the instance handle and the command line
; address.
; ------------------------------------------------------------------------
      
.code

; #########################################################################

; -----------------------------------------------------------------------
; The label "start:" is the address of the start of the code section and
; it has a matching "end start" at the end of the file. All procedures in
; this module must be written between these two.
; -----------------------------------------------------------------------

start:

      invoke GetModuleHandle, NULL
      mov hInstance, eax

      invoke GetCommandLine
      mov CommandLine, eax

      invoke InitCommonControls

      invoke LoadCursor,NULL,IDC_ARROW
      mov hCursor, eax

    ; --------------------------
    ; preset GLOBAL scope flags 
    ; --------------------------
      mov CaseFlag, 1
      mov WholeWord, 0
      mov CtrlFlag, 0

     ;call Main
      invoke WinMain,hInstance,NULL,CommandLine,SW_SHOWDEFAULT
      invoke ExitProcess,eax



; #########################################################################

Main proc

        ;====================
        ; Put LOCALs on stack
        ;====================

        ;LOCAL wc   :WNDCLASSEX
        ;LOCAL msg  :MSG

        ;LOCAL Wwd  :DWORD
        ;LOCAL Wht  :DWORD
        ;LOCAL Wtx  :DWORD
        ;LOCAL Wty  :DWORD
        ;LOCAL PathName[128]:BYTE

    LOCAL Wwd:DWORD,Wht:DWORD,Wtx:DWORD,Wty:DWORD

        ;==================================================
        ; Fill WNDCLASSEX structure with required variables
        ;==================================================


       invoke RegisterWinClass,ADDR WndProc,ADDR szClassName,
                      0,hCursor,COLOR_BTNFACE+1



        ;================================
        ; Centre window at following size
        ;================================

    invoke CreateWindowEx,WS_EX_LEFT,
                         ADDR szClassName,
                         ADDR szDisplayName,
                         WS_VISIBLE OR WS_CAPTION OR WS_SYSMENU OR WS_MINIMIZEBOX,
                         300,300,195,93,
                         NULL,NULL,
                         hInstance,NULL
   mov hWnd,eax

   DisplayMenu hWnd,600
   DisplayWindow hWnd,SW_SHOWNORMAL

      ;===================================
      ; Loop until PostQuitMessage is sent
      ;===================================


   call MsgLoop
   ret

Main endp

; #########################################################################

WinMain proc hInst:HINSTANCE,hPrevInst:HINSTANCE,CmdLine:LPSTR,CmdShow:DWORD

;WinMain proc hInst     :DWORD,
;             hPrevInst :DWORD,
;             CmdLine   :DWORD,
;             CmdShow   :DWORD

        ;====================
        ; Put LOCALs on stack
        ;====================

        LOCAL wc   :WNDCLASSEX
        LOCAL msg  :MSG
        LOCAL Wwd  :DWORD
        LOCAL Wht  :DWORD
        LOCAL Wtx  :DWORD
        LOCAL Wty  :DWORD
	LOCAL lpArg:DWORD
	LOCAL sWid :DWORD
	LOCAL sHgt :DWORD
	LOCAL hwnd :HWND
        LOCAL PathName[128]:BYTE

        ;==================================================
        ; Fill WNDCLASSEX structure with required variables
        ;==================================================

        invoke LoadIcon,hInst,500    ; icon about default icon ID
        mov hIconW, eax
        invoke LoadIcon,hInst,501    ; icon mainicon ID
        mov hIcon, eax
        invoke LoadIcon,hInst,501    ; icon 16x16 ID
        mov hIcon16, eax
        invoke LoadIcon,hInst,501    ; icon 32x32 ID
        mov hIcon32, eax

        mov wc.cbSize,         sizeof WNDCLASSEX
        mov wc.style,          CS_HREDRAW or CS_VREDRAW \
                               or CS_BYTEALIGNWINDOW
        mov wc.lpfnWndProc,    offset WndProc
        mov wc.cbClsExtra,     NULL
        mov wc.cbWndExtra,     NULL
        m2m wc.hInstance,      hInst
        mov wc.hbrBackground,  COLOR_BTNFACE+1
        mov wc.lpszMenuName,   NULL
        mov wc.lpszClassName,  offset szClassName
        m2m wc.hIcon,          hIcon16 ;icon from systembar
          invoke LoadCursor,NULL,IDC_ARROW
        mov wc.hCursor,        eax
        mov wc.hIconSm,        0

        invoke RegisterClassEx, ADDR wc

        ;================================
        ; Centre window at following size
        ;================================

       ;mov Wwd, 430
       ;mov Wht, 277

       	mov Wwd, 430
        mov Wht, 092

        invoke GetSystemMetrics,SM_CXSCREEN
        invoke TopXY,Wwd,eax
        mov Wtx, eax

        invoke GetSystemMetrics,SM_CYSCREEN
        invoke TopXY,Wht,eax
        mov Wty, eax

        invoke GetCurrentDirectory,128,ADDR PathName

    	invoke CreateWindowEx,WS_EX_OVERLAPPEDWINDOW,
                              ADDR szClassName,
                              ADDR szDisplayName,
                              WS_OVERLAPPEDWINDOW OR WS_VISIBLE OR WS_CAPTION OR WS_SYSMENU OR WS_MINIMIZEBOX,
			      Wtx,Wty,Wwd,Wht,
                              NULL,NULL,
                              hInstance,NULL
  	mov hWnd,eax

    ; ------------------------------
    ; get any command line filename
    ; ------------------------------
      invoke PathGetArgs,CommandLine
      mov lpArg, eax

      mov esi, eax
      lodsb
      cmp al, 0
      je noArgs       ; jump if no arg
      cmp al, 34
      jne @F          ; jump if no quote

      invoke PathUnquoteSpaces,lpArg
      mov lpArg, eax

      @@:

      invoke exist,lpArg
      .if eax == 1
        invoke StreamFileIn,hRichEd,lpArg
        invoke SetWindowText,hWnd,lpArg	;get filename

       ;invoke BASS_MusicFree, ModHandle
       ;invoke BASS_MusicLoad, 0, lpArg, 0, 0, BASS_MUSIC_LOOP OR \ 
       ;       BASS_MUSIC_POSRESET OR BASS_MUSIC_RAMPS          ; load musicfile
       ;test eax,eax
       ;jz error

        invoke BASS_MusicFree, ModHandle
        mov eax, BASS_SAMPLE_LOOP or BASS_MUSIC_POSRESET or BASS_MUSIC_RAMPS
        .if SurroundOn == TRUE
            or eax, BASS_MUSIC_SURROUND
        .endif
        invoke BASS_MusicLoad, 0, lpArg, 0, 0, eax, 0    ; load musicfile
        test eax,eax
        jz error
        
        mov [ModHandle], eax                                    ; save handle for future use
        invoke BASS_MusicGetName, ModHandle
        mov [ModName], eax

        invoke SendMessage, hWnd, WM_COMMAND, 50, 0 

       .else
        szText cantfind,"Sorry, cannot find that file."
        invoke MessageBox,hWnd,lpArg,ADDR cantfind,MB_OK
      .endif

      noArgs:
    ; ------------------------------

   	DisplayMenu hWnd,600	; menu ID
   	DisplayWindow hWnd,SW_SHOWNORMAL
        invoke UpdateWindow,hWnd



      ;===================================
      ; Loop until PostQuitMessage is sent
      ;===================================

    StartLoop:
      invoke GetMessage,ADDR msg,NULL,0,0
      cmp eax, 0
      je ExitLoop
      invoke TranslateMessage, ADDR msg
      invoke DispatchMessage,  ADDR msg
      jmp StartLoop
    ExitLoop:

      return msg.wParam

error:
    ret

WinMain endp

; #########################################################################
RegisterWinClass proc lpWndProc:DWORD, lpClassName:DWORD,
                      Icon:DWORD, Cursor:DWORD, bColor:DWORD

    LOCAL wc:WNDCLASSEX

    mov wc.cbSize,         sizeof WNDCLASSEX
    mov wc.style,          CS_BYTEALIGNCLIENT or \
                           CS_BYTEALIGNWINDOW
    m2m wc.lpfnWndProc,    lpWndProc
    mov wc.cbClsExtra,     NULL
    mov wc.cbWndExtra,     NULL
    m2m wc.hInstance,      hInstance
    m2m wc.hbrBackground,  bColor
    mov wc.lpszMenuName,   NULL
    m2m wc.lpszClassName,  lpClassName
    m2m wc.hIcon,          Icon
    m2m wc.hCursor,        Cursor
    m2m wc.hIconSm,        Icon

    invoke RegisterClassEx, ADDR wc

    ret

RegisterWinClass endp

; ########################################################################

MsgLoop proc

    LOCAL msg:MSG

    StartLoop:
      invoke GetMessage,ADDR msg,NULL,0,0
      cmp eax, 0
      je ExitLoop
      invoke TranslateMessage, ADDR msg
      invoke DispatchMessage,  ADDR msg
      jmp StartLoop
    ExitLoop:

    mov eax, msg.wParam
    ret

MsgLoop endp

; #########################################################################

WndProc proc hWin   :DWORD,
             uMsg   :DWORD,
             wParam :DWORD,
             lParam :DWORD

 
    LOCAL var    :DWORD
    LOCAL caW    :DWORD
    LOCAL caH    :DWORD   
    LOCAL Rct    :RECT
    LOCAL buffer1[128]:BYTE  ; these are two spare buffers
    LOCAL buffer2[128]:BYTE  ; for text manipulation etc..
    LOCAL szFileName[260]:BYTE
    LOCAL Ps     :PAINTSTRUCT
    LOCAL tbab   :TBADDBITMAP
    LOCAL tbb    :TBBUTTON
    LOCAL hTbar  :DWORD
    LOCAL hSbar  :DWORD
    LOCAL tl     :DWORD
    LOCAL hDC    :DWORD
    LOCAL lpTxt  :DWORD
    LOCAL nmh    :NMHDR
    LOCAL FileBuffer[260]:BYTE
    LOCAL hStatImage :DWORD
    LOCAL hStatIcon  :DWORD
    LOCAL hIcon1 :DWORD
    LOCAL hBmp   :DWORD
    LOCAL pt     :POINT
    LOCAL PathName[128]:BYTE

    .if uMsg == WM_COMMAND

    ;======== toolbar commands ========
        .if wParam == 50
        ;   invoke BASS_MusicPlay, ModHandle    ; old play tune
        ;   test eax,eax
        ;   jz error
        ;   invoke SetTimer, hWin, NULL, 50, NULL ;

            invoke BASS_ChannelPlay, ModHandle, 0    ; play tune
            test eax,eax
            jz error
            invoke SetTimer, hWin, NULL, 50, NULL ;  

        .elseif wParam == 51
            invoke BASS_ChannelStop, ModHandle

        .elseif wParam == 52
           ;invoke BASS_ChannelGetPosition, ModHandle
           ;dec ax
           ;and eax, 0000000011111111b
           ;qinvoke BASS_ChannelSetPosition, ModHandle, eax
           ;invoke BASS_MusicPreBuf, ModHandle     ; update pos if stopped

            invoke BASS_ChannelGetPosition, ModHandle
            .if eax != -1
                mov ebx, eax
                .while 1
                    dec ebx
                    and ebx, 0000000011111111b
                    qinvoke BASS_ChannelSetPosition, ModHandle, ebx
                .break .if eax
                .endw
            .endif

        .elseif wParam == 53
           ;invoke BASS_ChannelGetPosition, ModHandle
           ;inc ax
           ;and eax, 0000000011111111b
           ;qinvoke BASS_ChannelSetPosition, ModHandle, eax
           ;invoke BASS_MusicPreBuf, ModHandle     ; update pos if stopped

            invoke BASS_ChannelGetPosition, ModHandle
            .if eax !=-1
                mov ebx, eax
                .while 1
                    inc ebx
                    and ebx, 0000000011111111b
                    qinvoke BASS_ChannelSetPosition, ModHandle, ebx
                .break .if eax
                .endw
            .endif

        .elseif wParam == 54
           ;.if SurroundOn == FALSE
           ;    invoke BASS_MusicPlayEx, ModHandle, -1, BASS_MUSIC_LOOP OR \
           ;           BASS_MUSIC_POSRESET OR BASS_MUSIC_RAMPS OR BASS_MUSIC_SURROUND, 0
           ;    mov SurroundOn, TRUE
           ;.else
           ;     invoke BASS_MusicPlayEx, ModHandle, -1, BASS_MUSIC_LOOP OR \
           ;            BASS_MUSIC_POSRESET OR BASS_MUSIC_RAMPS, 0
           ;    mov SurroundOn, FALSE
           ;.endif

            .if SurroundOn == FALSE
                invoke BASS_ChannelSetFlags, ModHandle, BASS_SAMPLE_LOOP or \
                       BASS_MUSIC_POSRESET or BASS_MUSIC_RAMPS or BASS_MUSIC_SURROUND
                mov SurroundOn, TRUE
            .else
                 invoke BASS_ChannelSetFlags, ModHandle, BASS_SAMPLE_LOOP or \
                        BASS_MUSIC_POSRESET or BASS_MUSIC_RAMPS
                mov SurroundOn, FALSE
            .endif    
        .endif    

    ;======== menu commands ========

        .if wParam == 1001	; **** Open ****
            mov szFileName[0],0        ; set 1st byte to zero
            mov szFileName2[0],0       ; set 1st byte to zero

            mov ofn.lStructSize, sizeof OPENFILENAME
            m2m ofn.hWndOwner,   hWnd
            m2m ofn.hInstance,   hInstance
            m2m ofn.lpstrFilter, offset szFiles
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
            mov ofn.nFileExtension,0 
            mov ebx,offset szFileName2
            mov al,2Eh               ; look for the dot before file extention
;;
            inc ofn.nFileExtension   ; move the extention pointer for GetType use
            cmp ofn.nFileExtension,0 
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;             
            mov eax, ebp
            sub eax, 220h
            push eax
            pop ofn.lpstrFile
            mov ofn.nMaxFile,    sizeof szFileName
            m2m ofn.lpstrTitle,  offset szOpen
            mov ofn.Flags,       OFN_EXPLORER or OFN_FILEMUSTEXIST or \
                                 OFN_LONGNAMES
        
            invoke GetOpenFileName,ADDR ofn
            ;cmp szFileName[0],0    ; zero if cancel pressed in dlgbox
            .if eax == 0            ; if user Xcloses box
                ret
            .endif
            call GetType            ; get a file number from the extension.
            je @F

;;;;;;;;;;;; this is to get the file name in status bar ;) ;;;;;;;;;;;;;;;;;;;;

            invoke StreamFileIn,hRichEd,ADDR szFileName
            invoke SetWindowText,hWin,ADDR szFileName
           @@:
;;;;;;;;;;;; (c) OryNider 2005 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

           ;invoke BASS_MusicFree, ModHandle
           ;invoke BASS_MusicLoad, 0, ADDR szFileName, 0, 0, BASS_MUSIC_LOOP OR \ 
           ;       BASS_MUSIC_POSRESET OR BASS_MUSIC_RAMPS          ; load musicfile
           ;test eax,eax
           ;jz error

           invoke BASS_MusicFree, ModHandle
            mov eax, BASS_SAMPLE_LOOP or BASS_MUSIC_POSRESET or BASS_MUSIC_RAMPS
            .if SurroundOn == TRUE
                or eax, BASS_MUSIC_SURROUND
            .endif
            invoke BASS_MusicLoad, 0, ADDR szFileName, 0, 0, eax, 0    ; load musicfile
            test eax,eax
            jz error
        
            mov [ModHandle], eax                                    ; save handle for future use
            invoke BASS_MusicGetName, ModHandle
            mov [ModName], eax

            invoke SendMessage, hWin, WM_COMMAND, 50, 0 

            @@:

        .elseif wParam == 1010
            invoke SendMessage,hWin,WM_SYSCOMMAND,SC_CLOSE,NULL

        .elseif wParam == 2503 ; **** Insert (or Open) File ****
            mov szFileName[0],0     ; set 1st byte to zero

            mov ofn.lStructSize, sizeof OPENFILENAME
            m2m ofn.hWndOwner,   hWnd
            m2m ofn.hInstance,   hInstance
            m2m ofn.lpstrFilter, offset szFiles             
            mov eax, ebp
            sub eax, 220h
            push eax
            pop ofn.lpstrFile
            mov ofn.nMaxFile,    sizeof szFileName
            m2m ofn.lpstrTitle,  offset szOpen
            mov ofn.Flags,       OFN_EXPLORER or OFN_FILEMUSTEXIST or \
                                 OFN_LONGNAMES
        
            invoke GetOpenFileName,ADDR ofn
            cmp szFileName[0],0     ; zero if cancel pressed in dlgbox
            je @F

;;;;;;;;;;;; this is to get the file name in status bar ;)
            invoke StreamFileIn,hRichEd,ADDR szFileName
            invoke SetWindowText,hWin,ADDR szFileName
           @@:
;;;;;;;;;;;; (c) OryNider 2005

            invoke BASS_MusicFree, ModHandle
            mov eax, BASS_SAMPLE_LOOP or BASS_MUSIC_POSRESET or BASS_MUSIC_RAMPS
            .if SurroundOn == TRUE
                or eax, BASS_MUSIC_SURROUND
            .endif
            invoke BASS_MusicLoad, 0, ADDR szFileName, 0, 0, eax, 0    ; load musicfile
            test eax,eax
            jz error
        
            mov [ModHandle], eax                                    ; save handle for future use
            invoke BASS_MusicGetName, ModHandle
            mov [ModName], eax

            invoke SendMessage, hWin, WM_COMMAND, 50, 0 

            @@:

        .elseif wParam == 2502	; **** About ****
            szText AboutMsg,"Copyright � TBD 2oo2, � OryNider 2oo5",13,10,\
            "Bodin Florin Ciprian < orynider@rdslink.ro >"

            szText AboutTitle,"modplay"
            ;invoke ShellAbout,hWin,ADDR AboutTitle,ADDR AboutMsg,hIcon
            ;invoke ShellAbout, NULL, ADDR AppName2, ADDR Copyright, NULL
            invoke ShellAbout, hWin, ADDR AppName2, ADDR AboutMsg,hIconW 
	.elseif wParam == 3000	; **** Info ****
            invoke GetCurrentDirectory,128,ADDR PathName
	    invoke ShellExecute, NULL, NULL, ADDR HelpFile, NULL, NULL, SW_SHOWNORMAL

	.elseif lParam == 0	; **** Tray Commands ****
	    invoke Shell_NotifyIcon,NIM_DELETE,addr note
	    mov eax,wParam
		.if ax==IDM_RESTORE
		    invoke ShowWindow,hWnd,SW_RESTORE
			;.else
			;invoke DestroyWindow,hWnd
		.elseif ax==IDM_EXIT
		    invoke DestroyWindow,hWnd
		.endif
	.endif

    ;====== end menu commands ======
    .elseif uMsg == WM_TIMER
        invoke BASS_ChannelGetPosition, ModHandle
        mov edx, eax
        and eax, 0000000011111111b                      
        sar edx, 16
        invoke wsprintf, ADDR buffer1, ADDR szFormatString, eax, edx, ModName
        invoke SendMessage, hStatus, SB_SETTEXT, 0, ADDR buffer1    
                   
    .elseif uMsg == WM_CREATE
	invoke CreatePopupMenu
	mov hPopupMenu,eax
	invoke AppendMenu,hPopupMenu,MF_STRING,IDM_RESTORE,addr RestoreString
	invoke AppendMenu,hPopupMenu,MF_STRING,IDM_EXIT,addr ExitString
	;;
        invoke Do_ToolBar,hWin
        invoke Do_Status,hWin
        mov bmp.bmiHeader.biSize, sizeof bmp.bmiHeader
        mov bmp.bmiHeader.biWidth, VIS_WIDTH
        mov bmp.bmiHeader.biHeight, -VIS_HEIGHT
        mov bmp.bmiHeader.biPlanes, 1
        mov bmp.bmiHeader.biBitCount, 8
        mov bmp.bmiHeader.biClrUsed, 0FFh
        mov bmp.bmiHeader.biClrImportant, 0FFh
        invoke GetSysColor,COLOR_BTNFACE
        mov bmp.bmiColors, eax                   ; change from RGB to BGR
        mov cl, bmp.bmiColors.rgbRed
        mov bmp.bmiColors.rgbBlue, cl
        mov bmp.bmiColors.rgbRed, al        
        mov eax, sizeof bmp.bmiColors 
        mov bl, 255
        .while al < 0F0h                         ; create pallete
         sub bl, sizeof bmp.bmiColors
         mov bmp.bmiColors[eax].rgbRed, 0
         mov bmp.bmiColors[eax].rgbGreen, bl
         mov bmp.bmiColors[eax].rgbBlue, 0
         add al, sizeof bmp.bmiColors
        .endw
        invoke CreateDIBSection, 0, ADDR bmp, DIB_RGB_COLORS, ADDR specbuf, NULL, 0
        mov specbmp, eax
        invoke CreateCompatibleDC, 0
        mov specdc, eax
        invoke SelectObject, specdc, specbmp

        push hWin
        pop  hWinLevel
       ;invoke timeSetEvent, 25, 25, ADDR Level, 0, TIME_PERIODIC
        invoke timeSetEvent, 25, 25, ADDR Level, 0, TIME_PERIODIC
        mov timer, eax

   
       ;invoke BASS_Init, -1, 44100, 0, 0           ; Old BASS_Init
        invoke BASS_Init, 1, 44100, 0, hWin, 0      ; BASS_Init
        test eax,eax                                            
        jz error                                                
        							
        invoke BASS_Start                                       ; start BASS engine
        test eax,eax
        jz error
        
        mov SurroundOn, FALSE

    .elseif uMsg == WM_SYSCOLORCHANGE
        invoke Do_ToolBar,hWin
     
    .elseif uMsg == WM_KEYDOWN
        .IF wParam == VK_LEFT
            invoke SendMessage, hWin, WM_COMMAND, 52, 0 
        .ELSEIF wParam == VK_RIGHT        
            invoke SendMessage, hWin, WM_COMMAND, 53, 0 
        .ENDIF    

    .elseif uMsg == WM_SIZE                                    ; needed to update the status
	    .if wParam==SIZE_MINIMIZED
		mov note.cbSize,sizeof NOTIFYICONDATA
		push hWnd
		pop note.hwnd
		mov note.uID,IDI_TRAY
		mov note.uFlags,NIF_ICON+NIF_MESSAGE+NIF_TIP
		mov note.uCallbackMessage,WM_SHELLNOTIFY
		invoke LoadIcon,NULL,IDI_WINLOGO
		mov note.hIcon,eax
		invoke lstrcpy,addr note.szTip,addr AppName
		invoke ShowWindow,hWnd,SW_HIDE
		invoke Shell_NotifyIcon,NIM_ADD,addr note
	    .endif
        invoke SendMessage,hToolBar,TB_AUTOSIZE,0,0
        invoke MoveWindow,hStatus,0,0,0,0,TRUE

    .elseif uMsg==WM_SHELLNOTIFY
		.if wParam==IDI_TRAY
			.if lParam==WM_RBUTTONDOWN
				invoke GetCursorPos,addr pt
				invoke TrackPopupMenu,hPopupMenu,TPM_RIGHTALIGN,pt.x,pt.y,NULL,hWnd,NULL
			.elseif lParam==WM_LBUTTONDBLCLK
				invoke SendMessage,hWnd,WM_COMMAND,IDM_RESTORE,0
			.endif
		.endif

    .elseif uMsg == WM_CLOSE
    .elseif uMsg == WM_DESTROY
        invoke timeKillEvent, timer
        invoke KillTimer, hWin, NULL
        invoke BASS_Free
        .if hTbBmp != NULL  
          invoke DeleteObject, hTbBmp  
        .endif
        .if specbmp != NULL 
          invoke DeleteObject, specbmp 
        .endif
        .if specdc != NULL  
          invoke DeleteDC, specdc      
        .endif          
        invoke PostQuitMessage,NULL        
        return 0

    .endif

    invoke DefWindowProc,hWin,uMsg,wParam,lParam
error:
    ret

WndProc endp

; ##########################################################################

TopXY proc wDim:DWORD, sDim:DWORD

    shr sDim, 1      ; divide screen dimension by 2
    shr wDim, 1      ; divide window dimension by 2
    mov eax, wDim    ; copy window dimension into eax
    sub sDim, eax    ; sub half win dimension from half screen dimension

    return sDim

TopXY endp

; ########################################################################

GetFileName proc hParent:DWORD,lpTitle:DWORD,lpFilter:DWORD

    mov ofn.lStructSize,        sizeof OPENFILENAME
    m2m ofn.hWndOwner,          hParent
    m2m ofn.hInstance,          hInstance
    m2m ofn.lpstrFilter,        lpFilter
    m2m ofn.lpstrFile,          offset szFileNames
    mov ofn.nMaxFile,           sizeof szFileNames
    m2m ofn.lpstrTitle,         lpTitle
    mov ofn.Flags,              OFN_EXPLORER or OFN_FILEMUSTEXIST or \
                                OFN_LONGNAMES

    invoke GetOpenFileName,ADDR ofn

    ret

GetFileName endp

; #########################################################################

GetType proc
 
                                  ; set title into titleBuffer
    invoke GetFileTitle,addr szFileName2,addr titleBuffer,128
    invoke lstrlen,offset titleBuffer
    mov titLen,eax
   ;mov eax,offset szFileName
     xor ebx,ebx
     mov bx, ofn.nFileExtension   ; number of bytes to file extention
     add ebx,eax
     dec ebx                      ; ebx points to the dot before extention
     mov filept,offset FileEx     ; filept points to 1st dot of 1st ext in our data
     mov fileno,1
more:                   
    invoke lstrcmpi,ebx,filept    ; compare the two strings
     cmp eax,0                    
     je same                      ; go with fileno if match

    invoke lstrlen,filept         ; get len of our file ext
     inc eax                      ; plus trailing zero
     add filept,eax               ; update pointer
     inc fileno                   ; next file type number
     mov eax,max
     inc eax
     cmp fileno,eax               ; if max+1 - exit
     jne more                     ; do more
nosame:                           ; fileno = 0 if not found
     invoke Beep,hWnd,500
     mov fileno,0
same:
     mov eax,fileno               ; returns the fileno and eax

ret

GetType endp

; #########################################################################

SaveFileName proc hParent:DWORD,lpTitle:DWORD,lpFilter:DWORD

    mov ofn.lStructSize,        sizeof OPENFILENAME
    m2m ofn.hWndOwner,          hParent
    m2m ofn.hInstance,          hInstance
    m2m ofn.lpstrFilter,        lpFilter
    m2m ofn.lpstrFile,          offset szFileNames
    mov ofn.nMaxFile,           sizeof szFileNames
    m2m ofn.lpstrTitle,         lpTitle
    mov ofn.Flags,              OFN_EXPLORER or OFN_LONGNAMES
                                
    invoke GetSaveFileName,ADDR ofn

    ret

SaveFileName endp

; ########################################################################

Select_All Proc hEdit:DWORD

    LOCAL tl :DWORD
    LOCAL Cr :CHARRANGE

    mov Cr.cpMin,0

    invoke GetWindowTextLength,hEdit
    inc eax
    mov Cr.cpMax, eax

    invoke SendMessage,hEdit,EM_EXSETSEL,0,ADDR Cr

    ret

Select_All endp

; #########################################################################

Confirmation proc hEditor:DWORD

    invoke SendMessage,hEditor,WM_GETTEXTLENGTH,0,0
      cmp eax, 0
      jne @F
      return 0
    @@:
    invoke SendMessage,hEditor,EM_GETMODIFY,0,0
      cmp eax, 0  ; zero = unmodified
      jne @F
      return 0
      @@:

    szText confirm,"File is not saved, Save it now ?"

    invoke MessageBox,hWnd,ADDR confirm,
                           ADDR szDisplayName,
                           MB_YESNOCANCEL or MB_ICONQUESTION

    ret

Confirmation endp

; #########################################################################

Do_ToolBar proc hWin :DWORD

    LOCAL bSize :DWORD
    LOCAL tbab  :TBADDBITMAP
    LOCAL tbb   :TBBUTTON

    invoke LoadBitmap,hInstance,750
    mov hTbBmp,eax

    Create_Tool_Bar 16, 16

    TBextraData     ; additional data for TBBUTTON structure

    TBblank
    TBbutton  0,  50, TBSTYLE_BUTTON
    TBbutton  1,  51, TBSTYLE_BUTTON
    TBbutton  2,  52, TBSTYLE_BUTTON
    TBbutton  3,  53, TBSTYLE_BUTTON
    TBbutton  4,  54, TBSTYLE_CHECK

    ret

Do_ToolBar endp

; #########################################################################

Do_Status proc hParent:DWORD

    LOCAL sbParts[ 4] :DWORD

    invoke CreateStatusWindow,WS_CHILD or WS_VISIBLE,NULL, hParent, 200
    mov hStatus, eax

    ret

Do_Status endp

; ########################################################################

SetBmpColor proc hBitmap:DWORD

    LOCAL mDC       :DWORD
    LOCAL hBrush    :DWORD
    LOCAL hOldBmp   :DWORD
    LOCAL hReturn   :DWORD
    LOCAL hOldBrush :DWORD

    invoke CreateCompatibleDC,NULL
    mov mDC,eax

    invoke SelectObject,mDC,hBitmap
    mov hOldBmp,eax

    invoke GetSysColor,COLOR_BTNFACE
    invoke CreateSolidBrush,eax
    mov hBrush,eax

    invoke SelectObject,mDC,hBrush
    mov hOldBrush,eax

    invoke GetPixel,mDC,1,1   
    invoke ExtFloodFill,mDC,1,1,eax,FLOODFILLSURFACE

    invoke SelectObject,mDC,hOldBrush
    invoke DeleteObject,hBrush

    invoke SelectObject,mDC,hBitmap
    mov hReturn,eax
    invoke DeleteDC,mDC

    mov eax,hReturn

    ret

SetBmpColor endp

; #########################################################################

ofCallBack proc dwCookie:DWORD,pbBuff:DWORD,cb:DWORD,pcb:DWORD

    invoke ReadFile,dwCookie,pbBuff,cb,pcb,NULL

    mov eax, 0
    ret

ofCallBack endp

; #########################################################################

sfCallBack proc dwCookie:DWORD,pbBuff:DWORD,cb:DWORD,pcb:DWORD

    invoke WriteFile,dwCookie,pbBuff,cb,pcb,NULL

    mov eax, 0
    ret

sfCallBack endp

; #########################################################################

StreamFileIn proc hEdit:DWORD,lpszFileName:DWORD

    LOCAL hFile :DWORD
    LOCAL fSiz  :DWORD
    LOCAL ofs   :OFSTRUCT
    LOCAL est   :EDITSTREAM
    LOCAL buffer[32]:BYTE
    LOCAL aval[8]:BYTE

    invoke OpenFile,lpszFileName,ADDR ofs,OF_READ
    mov hFile, eax

    mov est.dwCookie, eax
    mov est.dwError, 0
    mov eax, offset ofCallBack
    mov est.pfnCallback, eax

    invoke SendMessage,hEdit,EM_STREAMIN,SF_TEXT,ADDR est

    invoke GetFileSize,hFile,NULL
    mov fSiz, eax

    invoke CloseHandle,hFile

    szText OpenMsg,"Opened at "
    szText OpenByt," bytes"

    mov buffer[0], 0

    invoke szCatStr,ADDR buffer,ADDR OpenMsg

    invoke dwtoa,fSiz,ADDR aval
    invoke szCatStr,ADDR buffer,ADDR aval
    invoke szCatStr,ADDR buffer,ADDR OpenByt

    invoke SendMessage,hStatus,SB_SETTEXT,3,ADDR buffer

    invoke SendMessage,hEdit,EM_SETMODIFY,0,0

    mov eax, 0
    ret

StreamFileIn endp

; #########################################################################

StreamFileOut proc hEdit:DWORD,lpszFileName:DWORD

    LOCAL hFile :DWORD
    LOCAL fSiz  :DWORD
    LOCAL ofs   :OFSTRUCT
    LOCAL est   :EDITSTREAM
    LOCAL buffer[32]:BYTE
    LOCAL aval[8]:BYTE

    invoke GetWindowTextLength,hEdit
    mov fSiz, eax

    szText CloseMsg,"Saved at "
    szText CloseByt," bytes"

    mov buffer[0], 0

    invoke szCatStr,ADDR buffer,ADDR CloseMsg

    invoke dwtoa,fSiz,ADDR aval
    invoke szCatStr,ADDR buffer,ADDR aval
    invoke szCatStr,ADDR buffer,ADDR CloseByt

    szText sfTest,"Test"

    invoke SendMessage,hStatus,SB_SETTEXT,3,ADDR buffer

    invoke OpenFile,lpszFileName,ADDR ofs,OF_CREATE
    mov hFile, eax

    mov est.dwCookie, eax
    mov est.dwError, 0
    mov eax, offset sfCallBack
    mov est.pfnCallback, eax

    invoke SendMessage,hEdit,EM_STREAMOUT,SF_TEXT,ADDR est
    invoke CloseHandle,hFile

    invoke SendMessage,hEdit,EM_SETMODIFY,0,0

    mov eax, 0
    ret

StreamFileOut endp

; ########################################################################

MergeFile proc hEdit:DWORD

    LOCAL poz   :DWORD
    LOCAL hFile :DWORD
    LOCAL hMem  :DWORD
    LOCAL ln    :DWORD
    LOCAL br    :DWORD
    LOCAL Cr    :CHARRANGE
    LOCAL szFileName[260]:BYTE

    jmp @F
      szTitleM   db "Merge File",0
      szFilterM  db "All files",0,"*.*",0,
                    "Text files",0,"*.TEXT",0,0
    @@:

    mov szFileName[0],0
    invoke GetFileName,hWnd,ADDR szTitleM,ADDR szFilterM

    cmp szFileName[0],0  ;<< zero if cancel pressed in dlgbox
    je @F
      invoke CreateFile,ADDR szFileName,
                        GENERIC_READ,
                        FILE_SHARE_READ,
                        NULL,OPEN_EXISTING,
                        FILE_ATTRIBUTE_NORMAL,
                        NULL
      mov hFile, eax

      invoke GetFileSize,hFile,NULL
      mov ln, eax

      stralloc ln
      mov hMem, eax
    
      invoke ReadFile,hFile,hMem,ln,ADDR br,NULL
      invoke SendMessage,hEdit,EM_REPLACESEL,0,hMem

      strfree hMem
    @@:

    ret

MergeFile endp

; #########################################################################


Level proc uses ebx, p1,p2,p3,p4,p5 :DWORD

    LOCAL hDC         :DWORD
    LOCAL buffer1[12] :BYTE

    .if ModHandle != 0
       invoke GetDC, hWinLevel
       mov hDC, eax

       mov ecx, [specbuf]                             ; clear window
       xor ebx, ebx
       .while ebx < VIS_WIDTH * VIS_HEIGHT
         mov BYTE PTR [ebx+ecx], 0
         inc ebx
       .endw
       
       invoke BASS_ChannelGetLevel, ModHandle
       mov ecx, [specbuf]
       .if eax != -1                                  ; error?
        .if al > VIS_WIDTH                            ; level exceed VIS_WIDTH
          mov al, VIS_WIDTH 
        .endif 
        xor ebx, ebx
        .while bl < al                                ; display level
          mov BYTE PTR [ebx+ecx], bl                  ; line 1
          mov BYTE PTR [ebx+ecx+VIS_WIDTH], bl        ; line 2
          mov BYTE PTR [ebx+ecx+VIS_WIDTH*2], bl      ; line 3              
          mov BYTE PTR [ebx+ecx+VIS_WIDTH*3], bl      ; line 4 
         ;mov BYTE PTR [ebx+ecx+VIS_WIDTH*4], bl      ; gdi error                        
          inc bl        
        .endw
		ror eax,16         ; get right channel
		add ecx,VIS_WIDTH*5
        .if al > VIS_WIDTH                            ; level exceed VIS_WIDTH
          mov al, VIS_WIDTH 
        .endif 
        xor ebx, ebx
        .while bl < al                                ; display level
          mov BYTE PTR [ebx+ecx], bl                  ; line 1
          mov BYTE PTR [ebx+ecx+VIS_WIDTH], bl        ; line 2
          mov BYTE PTR [ebx+ecx+VIS_WIDTH*2], bl      ; line 3              
          mov BYTE PTR [ebx+ecx+VIS_WIDTH*3], bl      ; line 4 
         ;mov BYTE PTR [ebx+ecx+VIS_WIDTH*4], bl      ; gdi error                        
          inc bl        
        .endw
       .endif 
       invoke BitBlt, hDC, 125, 9, VIS_WIDTH,VIS_HEIGHT, specdc, 0, 0, SRCCOPY
       invoke ReleaseDC, hWinLevel, hDC
    .endif
    
    ret

Level endp

; #########################################################################


end start

; ############################################################### [ END ] ##########

