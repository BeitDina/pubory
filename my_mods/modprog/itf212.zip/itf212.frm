TITLE    : Impulse Tracker Font Editor v2.12
AUTHOR   : ZaStaR
GROUP    :
CATEGORY : trackers
EMAIL    : zastar@uclink4.berkeley.edu

--DESCRIPTION-BEGIN------------------------------------------------------------
Edits the font Impulse Tracker uses.  Tired of the illegible DOS fonts IT is forced to use?  Load from a new selection of fonts or make your own.
--DESCRIPTION-END--------------------------------------------------------------
