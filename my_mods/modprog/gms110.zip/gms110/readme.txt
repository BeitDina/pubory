This archive contains Game Music System 1.1, released on February 10, 1997.

ADLIBSP.RAD is a RAD module, composed by Purple Motion.

INNOVATE.AMD is an AMusic module, composed by Bird.

The csdpmi3b/ directory contains CWSDPMI, a free DPMI server. If GMS
complains about there being no DPMI server at startup, you need to use this
program. If not, you can ignore it.

The source/ directory contains the source code to the playroutine.

The midi/ directory contains 128 FM instruments which correspond to the
General MIDI patch set. These instruments are taken from the Allegro game
library. They are intended to help with the MIDI loader routine, but should
prove to be a useful starting point for your own tunes.

The following information is required by Simtel.net's upload policy:
1. GMS is a music composition program, targeted at people who make games.
2. Installation is described in chapter 1 of the manual.
3. The editor is shareware. The other parts of the package are public
   domain.
4. This archive is freely redistributable, but must be distributed in its
   original form.
5. The author can be contacted at the email address malyon@netcom.com.

Good luck!

- Roland Acton
