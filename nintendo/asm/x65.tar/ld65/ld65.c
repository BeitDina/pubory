/*
 * Linker for x65 development system.  VERY basic...
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include "exec65.h"

#define SEGSIZE	0x10000
#define SEGMASK	0x0ffff

char *outfile = "x65.out";
int makexout = 1;

struct object {
	char *fname;
	int textstart;		/* start of real text for this .o */
	int datastart;		/* start of real text for this .o */
	int bssstart;		/* start of real text for this .o */
	int pad;
	struct exec65 hdr;
	unsigned char *txt;
	unsigned char *dat;
	struct reloc65 *reltab;
	struct object *next;
};

struct sym {
	struct sym65 *s;
	int emit;
	struct object *o;
	struct sym *next;
};
struct sym *lookup(char *name);
struct sym *install(struct sym65 *s, struct object *o);

struct sym65 etext_sym = { "_etext", S_TEXT, 0, 0, 0 };
struct sym65 edata_sym = { "_edata", S_DATA, 0, 0, 0 };
struct sym65 end_sym = { "_end", S_BSS, 0, 0, 0 };

#define HSIZE	101
struct sym *symtab[HSIZE];

int textstart = 0x8000;
int datastart = -1;
int bssstart = -1;
int padtext = 1;

int textsize = 0;
int datasize = 0;
int bsssize = 0;

struct object *objects;
struct object **nxtobj;

long getbytes(unsigned char *p, int len);
void patchbytes(unsigned char *mem, int len, long value);

main(int argc, char **argv)
{
	int c;
	unsigned u;
	while ((c = getopt(argc, argv, "T:D:p")) != EOF)
		switch(c) {
		case 'T':
			textstart = (unsigned)strtol(optarg, NULL, 0);
			break;
		case 'D':
			datastart = (unsigned)strtol(optarg, NULL, 0);
			break;
		case 'o':
			outfile = optarg;
			break;
		case 'p':
			padtext++;
			break;
		}

	while (optind < argc)
		readobj(argv[optind++]);

	layout_sections();
	perform_relocations();
	layout_symbols();
	patch_undefs();

	if (check_undefs())
		write_object_file();
}

write_object_file()
{
	struct exec65 a;
	struct object *o;
	struct sym *s;
	FILE *fo;
	int i;

	a.e_magic = EMAGIC;
	a.e_entry = textstart;
	a.e_text = textsize;
	a.e_data = datasize;
	a.e_bss = bsssize;
	a.e_nreloc = 0;
	a.e_nsym = count_symbols();
	if ((fo = fopen(outfile, "w")) == NULL) {
		fprintf(stderr, "Can't create %s\n", outfile);
		exit(1);
	}
	fwrite(&a, sizeof(a), 1, fo);
	for(o = objects; o != NULL ;o = o->next) {
		if (o->hdr.e_text)
			fwrite(o->txt, o->hdr.e_text, 1, fo);
		if (o->pad)
			write_pad(o->pad, fo);
	}
	for(o = objects; o != NULL ;o = o->next)
		if (o->hdr.e_data)
			fwrite(o->dat, o->hdr.e_data, 1, fo);
	for(i = 0; i < HSIZE ;i++)
		for(s = symtab[i]; s != NULL ;s = s->next)
			if (s->emit)
				fwrite(s->s, sizeof(*s->s), 1, fo);
	fclose(fo);
}

write_pad(int len, FILE *fo)
{
	static char zerobuf[256];
	while (len > sizeof(zerobuf)) {
		fwrite(zerobuf, sizeof(zerobuf), 1, fo);
		len -= sizeof(zerobuf);
	}
	if (len)
		fwrite(zerobuf, len, 1, fo);
}

count_symbols()
{
	struct sym *s;
	int i, n = 0;
	for(i = 0; i < HSIZE ;i++)
		for(s = symtab[i]; s != NULL ;s = s->next)
			if (s->emit)
				n++;
	return n;
}

/*
 * Print a message and return 0 if any unresolved symbols
 * remain.
 */
check_undefs()
{
	struct sym *s;
	int i;
	for(i = 0; i < HSIZE ;i++)
		for(s = symtab[i]; s != NULL ;s = s->next)
			if (s->s->s_type&S_UNDEF) {
				fprintf(stderr, "Undefined externals remain\n");
				return 0;
			}
	return 1;
}

/*
 * For every undefined symbol reference lookup the
 * definition and patch the location with the symbol's
 * value.
 */
patch_undefs()
{
	struct sym *s, *t;
	unsigned char *dst;
	int i;
	for(i = 0; i < HSIZE ;i++)
		for(s = symtab[i]; s != NULL ;s = s->next)
			if (s->s->s_type&S_UNDEF) {
				t = lookup(s->s->s_name);
				if (t == NULL) {
					fprintf(stderr, "undefined: %s\n",
						s->s->s_name);
					continue;
				}
				switch(s->s->s_type&S_SEGMASK) {
				case S_TEXT:
					dst = &s->o->txt[s->s->s_value];
					break;
				case S_DATA:
					dst = &s->o->dat[s->s->s_value];
					break;
				default:
					dst = NULL;
				}
				patchbytes(dst, s->s->s_size, t->s->s_value);
				s->s->s_type &= S_SEGMASK;
			}
}

/*
 * For each .o we already laid out the segment offsets
 * in layout_sections(), now we allocate absolute
 * addresses for every defined symbol by taking the symbols
 * .o address and adding the approptiate segment offset.
 */
layout_symbols()
{
	struct sym *s;
	int i;
	for(i = 0; i < HSIZE ;i++)
		for(s = symtab[i]; s != NULL ;s = s->next)
			if (!(s->s->s_type&S_UNDEF) && s->o)
				switch(s->s->s_type) {
				case S_TEXT:
					s->s->s_value += s->o->textstart;
					break;
				case S_DATA:
					s->s->s_value += s->o->datastart;
					break;
				case S_BSS:
					s->s->s_value += s->o->bssstart;
					break;
				}
}

/*
 * When assembled .o files assume text, data and bss all start
 * at 0.  layout_sections() computed the real start positions
 * for each .o file, we now add these values to any symbol
 * references within the .o file. i.e.:
 *	foo:	.word	123
 *		.text
 *		lda	foo
 *
 * would get assembled with foo at 0 and the code for the 'lda'
 * would contain 'lda 0' with a relocation indicating that if you
 * move foo you need to add the value of the new address to the
 * contents of the 2 bytes following the 'lda'...
 */
perform_relocations()
{
	struct object *o;
	unsigned long v;
	unsigned char *src;
	int i, n, offset;
	for(o = objects; o != NULL ;o = o->next)
		if (o->hdr.e_nreloc) {
			for(i = 0; i < o->hdr.e_nreloc ;i++) {
				switch(o->reltab[i].r_seg) {
				case S_TEXT:
					src = &o->txt[o->reltab[i].r_addr];
					break;
				case S_DATA:
					src = &o->dat[o->reltab[i].r_addr];
					break;
				default:
					src = NULL;
				}
				switch(o->reltab[i].r_targ) {
				case S_TEXT:
					offset = o->textstart;
					break;
				case S_DATA:
					offset = o->datastart;
					break;
				case S_BSS:
					offset = o->bssstart;
					break;
				default:
					fprintf(stderr,
						"Reloc targ seg bad (%d)\n",
							o->reltab[i].r_targ);
					src = NULL;
				}
				n = o->reltab[i].r_size;
				if (src)
					patchbytes(src, n,
						getbytes(src, n) + offset);
				else {
					fprintf(stderr,
						"relocation seg is NULL!\n");
					exit(1);
				}
			}
		}
}

/*
 * Every .o file is assembled with text, data and bss starting
 * at 0.  Here we loop through the .o files and compute real
 * offsets for each .o.  The basic algorithm:
 *	- concatenate text sections starting at 'textstart'
 *	- concatenate data sections starting at the
 *		end of the text if datastart = -1 otherwise
 *		start at datastart.
 *	- concatenate bss sections starting at the end of
 *		the data section.
 */
layout_sections()
{
	struct object *o;
	long n;
	n = textstart;
	/*
	 * The 65816 doesn't like it when text sections cross
	 * 64k boundries.  Add some padding if necessary...
	 */
	for(o = objects; o != NULL ;o = o->next) {
		o->textstart = n;
		n += o->hdr.e_text;
		if (padtext && o->next && (n&~SEGMASK) !=
				((n+o->next->hdr.e_text-1)&~SEGMASK)) {
			o->pad = ((n + SEGSIZE - 1)&~SEGMASK) - n;
printf("pad added %d\n", o->pad);
			n += o->pad;
		}
		textsize += o->hdr.e_text + o->pad;
	}

	/*
	 * Create a symbol indicating the end of the text segment.
	 */
	etext_sym.s_value = n;
	(void)install(&etext_sym, NULL);

	if (datastart >= 0)
		n = datastart;
	for(o = objects; o != NULL ;o = o->next) {
		o->datastart = n;
		n += o->hdr.e_data;
		datasize += o->hdr.e_data;
	}

	/*
	 * Create a symbol indicating the end of the data segment.
	 */
	edata_sym.s_value = n;
	(void)install(&edata_sym, NULL);

	for(o = objects; o != NULL ;o = o->next) {
		o->bssstart = n;
		n += o->hdr.e_bss;
		bsssize += o->hdr.e_bss;
	}

	/*
	 * Create a symbol indicating the end of the program
	 */
	end_sym.s_value = n;
	(void)install(&end_sym, NULL);
}

readobj(char *name)
{
	struct object *o;
	struct exec65 a;
	FILE *fi;

	if ((fi = fopen(name, "r")) == NULL) {
		fprintf(stderr, "Can't open %s\n", name);
		exit(1);
	}
	fread(&a, sizeof(a), 1, fi);
	if (a.e_magic != RMAGIC && a.e_magic != EMAGIC) {
		fprintf(stderr, "Invalid x65 header\n");
		exit(1);
	}

	o = (struct object *)malloc(sizeof(struct object));
	o->hdr = a;
	o->pad = 0;
	if (objects == NULL)
		objects = o;
	else
		*nxtobj = o;
	nxtobj = &o->next;
	o->fname = name;
	o->next = NULL;
	if (o->hdr.e_text) {
		o->txt = (char *)malloc(o->hdr.e_text);
		fread(o->txt, o->hdr.e_text, 1, fi);
	} else
		o->txt = NULL;
	if (o->hdr.e_data) {
		o->dat = (char *)malloc(o->hdr.e_data);
		fread(o->dat, o->hdr.e_data, 1, fi);
	} else
		o->dat = NULL;
	if (o->hdr.e_nreloc) {
		o->reltab = (struct reloc65 *)
			malloc(sizeof(struct reloc65) * o->hdr.e_nreloc);
		fread(o->reltab, sizeof(struct reloc65), o->hdr.e_nreloc, fi);
	}
	if (o->hdr.e_nsym) {
		struct sym65 *syms;
		int i;
		syms = (struct sym65 *)
			malloc(sizeof(struct sym65) * o->hdr.e_nsym);
		fread(syms, sizeof(struct sym65), o->hdr.e_nsym, fi);
		for(i = 0; i < o->hdr.e_nsym ;i++)
			install(&syms[i], o);
	}
	fclose(fi);
}

void
patchbytes(unsigned char *mem, int len, long value)
{
	while (len-- > 0) {
		*mem++ = value % 256;
		value /= 256;
	}
}

long
getbytes(unsigned char *p, int len)
{
	long v = 0;
	while (len-- > 0)
		v = 256*v + *p++;
	return v;
}

hash(char *str)
{
	int ret = 0;
	while (*str)
		ret = (*str++ + ret) % HSIZE;
	return ret;
}

#ifdef DEBUG
dump_symtab()
{
	struct sym *s;
	int i;
	for(i = 0; i < HSIZE ;i++)
		for(s = symtab[i]; s != NULL ;s = s->next) {
			printf("%s %sdefined, value=0x%x\n",
				s->s->s_name,
				(s->s->s_type&S_UNDEF) ? "un" : "",
				s->s->s_value);
		}
}
#endif

struct sym *
lookup(char *str)
{
	int slot = hash(str);
	register struct sym *p;
	for(p = symtab[slot]; p != NULL ;p = p->next)
		if (strcmp(str, p->s->s_name) == 0 && !(p->s->s_type&S_UNDEF))
			break;
	return p;
}

struct sym *
install(struct sym65 *s, struct object *o)
{
	int slot = hash(s->s_name);
	register struct sym *p = NULL;
	if (!(s->s_type&S_UNDEF)) {
		for(p = symtab[slot]; p != NULL ;p = p->next)
			if (strcmp(s->s_name, p->s->s_name) == 0 &&
					!(p->s->s_type&S_UNDEF))
				break;
	}
	if (p == NULL) {
		p = (struct sym *)malloc(sizeof(struct sym));
		p->s = s;
		p->o = o;
		p->emit = !(s->s_type&S_UNDEF);
		p->next = symtab[slot];
		symtab[slot] = p;
	} else {
		fprintf(stderr, "Multiple definitions for %s\n",
			s->s_name);
		exit(1);
	}
	return p;
}
