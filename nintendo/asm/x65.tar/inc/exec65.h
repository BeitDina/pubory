/*
 * Object file format for x65 development system.  Each
 * file is:
 *	exec65 header
 *	header.size bytes of data (text and data mixed)
 *	header.nreloc relocation entries (0 for EMAGIC files)
 *	header.nsym exported symbol entries
 *
 */

typedef unsigned long ulong;

struct exec65 {
	ulong e_magic;	/* magic number */
	ulong e_entry;	/* load remainder here... */
	ulong e_text;	/* text segment size... */
	ulong e_data;	/* data segment size... */
	ulong e_bss;	/* bss... */
	ulong e_nreloc;	/* number of relocation entries */
	ulong e_nsym;	/* number of exported symbols */
};

struct reloc65 {
	ulong r_addr;		/* offset requiring relocation */
	ulong r_size:2,	/* 1, 2 or 3 */
		r_seg:4,		/* segment relocation resides in */
		r_targ:4,		/* segment relocation refers to */
		_pad:22;		/* pad to 32 bits */
};

#define MAXSYMLEN	16
struct sym65 {
	char s_name[MAXSYMLEN];
	ulong s_type:4, s_size:4, _pad:24;
	ulong s_value;
};
#define S_ABS	0x0
#define S_TEXT	0x1
#define S_DATA	0x2
#define S_BSS	0x3
#define S_UNDEF	0x8	/* 'or'ed with above */
#define S_SEGMASK 0x7

#define RMAGIC	0500	/* relocatable .o format */
#define EMAGIC	0501	/* fully bound object file */
