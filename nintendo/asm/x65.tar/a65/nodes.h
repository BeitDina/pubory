#include <stdio.h>
#include <setjmp.h>
#include "exec65.h"

#define F_BRANCH	0x01
#define F_BRANCHL	0x02
#define F_JSL		0x04
#define F_PSEUDOB	0x08	/* pseudo branch */

struct node {
	int n_op;
	union {
		struct {
			struct node *l, *r;
		} interior;
		struct sym *s;
		int i;
	} x;
#define n_left	x.interior.l
#define n_right	x.interior.r
#define n_sym	x.s
#define n_val	x.i
};

struct segment {
	unsigned char *mem;
	int dot;
	int type;		/* S_TEXT, etc from exec65.h */
};
extern struct segment textseg, dataseg, bssseg, *curseg;

struct sym {
	char *name;
	int val;
	struct segment *seg;
	int defined;
	int exported;
	struct sym *next;
};

struct patch {
	int addr;
	struct segment *seg;
	int size;
	int lineno;
	int resolved;		/* 0=unresolved, 1=resolved, 2=need extern */
	struct node *etree;
	struct patch *next;
};
extern struct patch *patchlist;

struct reloc {
	unsigned short addr;	/* offset in segment to relocate */
	int size;		/* number of bytes to patch */
	int seg;		/* segment addr refers to */
	int targ;		/* segment contents of addr refer to */
	struct reloc *next;
};
extern struct reloc *reloclist;

struct {
	int memused;
} stats;

struct etype {
	int value;
	struct segment *seg;
};
jmp_buf evaljmp;
#define E_CONST	1
#define E_ADDR	2

extern int lineno;

extern struct opcode optab[];
extern insn(int op, struct node *etree, int type, int nbytes);
extern struct node *makenode(int op, struct node *l, struct node *r);
extern struct node *makesym(struct sym *s);
extern struct node *makeconst(int val);
extern struct sym *lookup(char *name);
extern struct sym *install(char *name, struct segment *cs, int defined);
extern struct etype eval(struct node *etree);
extern struct sym *constsym(struct segment *cs, int value);
extern int everysym(int (*)());
extern void *xmalloc(int nbytes);
extern void xfree(void *ptr, int nbytes);
extern void addreloc(struct segment *src, struct segment *dst,
	int addr, int size);
