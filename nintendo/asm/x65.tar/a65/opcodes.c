/*
 * $Log: opcodes.c,v $
 * Revision 1.1  1993/12/10  02:07:40  mercier
 * Initial revision
 *
 */
#include "opcodes.h"
#include "nodes.h"

static struct modeop op_adc[] = {
	{M_IMM, 0x69}, {M_DIRECT, 0x65}, {M_DIRX, 0x75},
	{M_DIRIND, 0x72}, {M_DIRIDXIND, 0x61}, {M_DIRINDIDX, 0x71},
	{M_DIRINDLONG, 0x67}, {M_DIRINDLONGIDX, 0x77}, {M_ABS, 0x6d},
	{M_ABSX, 0x7d}, {M_ABSY, 0x79}, {M_ABSLONG, 0x6f},
	{M_ABSLONGX, 0x7f}, {M_STACKREL, 0x63}, {M_STACKRELINDIDX, 0x73},
	{0, 0}
};
static struct modeop op_and[] = {
	{M_IMM, 0x29}, {M_DIRECT, 0x25}, {M_DIRX, 0x35},
	{M_DIRIND, 0x32}, {M_DIRIDXIND, 0x21}, {M_DIRINDIDX, 0x31},
	{M_DIRINDLONG, 0x27}, {M_DIRINDLONGIDX, 0x37}, {M_ABS, 0x2d},
	{M_ABSX, 0x3d}, {M_ABSY, 0x39}, {M_ABSLONG, 0x2f},
	{M_ABSLONGX, 0x3f}, {M_STACKREL, 0x23}, {M_STACKRELINDIDX, 0x33},
	{0, 0}
};
static struct modeop op_asl[] = {
	{M_ACC, 0x0a}, {M_DIRECT, 0x06}, {M_DIRX, 0x16},
 	{M_ABS, 0x0e}, {M_ABSX, 0x1e},
 	{0, 0}
};
static struct modeop op_bcc[] = {
	{M_REL, 0x90},
	{0, 0},
};
static struct modeop op_bcs[] = {
	{M_REL, 0xb0},
	{0, 0},
};
static struct modeop op_beq[] = {
	{M_REL, 0xf0},
	{0, 0},
};
static struct modeop op_bit[] = {
	{M_IMM, 0x89}, {M_DIRECT, 0x24}, {M_DIRX, 0x34},
 	{M_ABS, 0x2c}, {M_ABSX, 0x3c},
 	{0, 0}
};
static struct modeop op_bmi[] = {
	{M_ABSLONG, 0x30},
	{0, 0},
};
static struct modeop op_bne[] = {
	{M_REL, 0xd0},
	{0, 0},
};
static struct modeop op_bpl[] = {
	{M_REL, 0x10},
	{0, 0},
};
static struct modeop op_bra[] = {
	{M_REL, 0x80},
	{0, 0},
};
static struct modeop op_brk[] = {
	{M_IMM, 0x00},
	{0, 0},
};
static struct modeop op_brl[] = {
	{M_RELLONG, 0x82},
	{0, 0},
};
static struct modeop op_bvc[] = {
	{M_REL, 0x50},
	{0, 0},
};
static struct modeop op_bvs[] = {
	{M_REL, 0x70},
	{0, 0},
};
static struct modeop op_clc[] = {
	{M_IMPL, 0x18},
	{0, 0},
};
static struct modeop op_cld[] = {
	{M_IMPL, 0xd8},
	{0, 0},
};
static struct modeop op_cli[] = {
	{M_IMPL, 0x58},
	{0, 0},
};
static struct modeop op_clv[] = {
	{M_IMPL, 0xb8},
	{0, 0},
};
static struct modeop op_cmp[] = {
	{M_IMM, 0xc9}, {M_DIRECT, 0xc5}, {M_DIRX, 0xd5},
	{M_DIRIND, 0xd2}, {M_DIRIDXIND, 0xc1}, {M_DIRINDIDX, 0xd1},
	{M_DIRINDLONG, 0xc7}, {M_DIRINDLONGIDX, 0xd7}, {M_ABS, 0xcd},
	{M_ABSX, 0xdd}, {M_ABSY, 0xd9}, {M_ABSLONG, 0xcf},
	{M_ABSLONGX, 0xdf}, {M_STACKREL, 0xc3}, {M_STACKRELINDIDX, 0xd3},
	{0, 0}
};
static struct modeop op_cop[] = {
	{M_IMM, 0x02},
	{0, 0},
};
static struct modeop op_cpx[] = {
	{M_IMM, 0xe0}, {M_DIRECT, 0xe4}, {M_ABS, 0xec},
 	{0, 0}
};
static struct modeop op_cpy[] = {
	{M_IMM, 0xc0}, {M_DIRECT, 0xc4}, {M_ABS, 0xcc},
 	{0, 0}
};
static struct modeop op_dec[] = {
	{M_ACC, 0x3a}, {M_DIRECT, 0xc6}, {M_DIRX, 0xd6},
	{M_ABS, 0xce}, {M_ABSX, 0xde},
	{0, 0}
};
static struct modeop op_dex[] = {
	{M_IMPL, 0xca},
	{0, 0}
};
static struct modeop op_dey[] = {
	{M_IMPL, 0x88},
	{0, 0}
};
static struct modeop op_eor[] = {
	{M_IMM, 0x49}, {M_DIRECT, 0x45}, {M_DIRX, 0x55},
	{M_DIRIND, 0x52}, {M_DIRIDXIND, 0x41}, {M_DIRINDIDX, 0x51},
	{M_DIRINDLONG, 0x47}, {M_DIRINDLONGIDX, 0x57}, {M_ABS, 0x4d},
	{M_ABSX, 0x5d}, {M_ABSY, 0x59}, {M_ABSLONG, 0x4f},
	{M_ABSLONGX, 0x5f}, {M_STACKREL, 0x43}, {M_STACKRELINDIDX, 0x53},
	{0, 0}
};
static struct modeop op_inc[] = {
	{M_ACC, 0x1a}, {M_DIRECT, 0xe6}, {M_DIRX, 0xf6},
	{M_ABS, 0xee}, {M_ABSX, 0xfe},
	{0, 0}
};
static struct modeop op_inx[] = {
	{M_IMPL, 0xe8},
	{0, 0}
};
static struct modeop op_iny[] = {
	{M_IMPL, 0xc8},
	{0, 0}
};
static struct modeop op_jcc[] = {
	{M_REL, 0xb0},
	{M_REL, 0x90},
	{0, 0}
};
static struct modeop op_jcs[] = {
	{M_REL, 0x90},
	{M_REL, 0xb0},
	{0, 0}
};
static struct modeop op_jeq[] = {
	{M_REL, 0xd0},
	{M_REL, 0xf0},
	{0, 0}
};
static struct modeop op_jmi[] = {
	{M_REL, 0x10},
	{M_REL, 0x30},
	{0, 0}
};
static struct modeop op_jml[] = {
	{M_ABSIND, 0xdc},
	{0, 0}
};
static struct modeop op_jmp[] = {
	{M_ABS, 0x4c}, {M_ABSIND, 0x6c}, {M_ABSIDXIND, 0x7c},
	{M_ABSLONG, 0x5c},
	{0, 0}
};
static struct modeop op_jne[] = {
	{M_REL, 0xf0},
	{M_REL, 0xd0},
	{0, 0}
};
static struct modeop op_jpl[] = {
	{M_REL, 0x30},
	{M_REL, 0x10},
	{0, 0}
};
static struct modeop op_jsl[] = {
	{M_ABSLONG, 0x22},
	{0, 0}
};
static struct modeop op_jsr[] = {
	{M_ABS, 0x20}, {M_ABSIDXIND, 0xfc},
	{0, 0}
};
static struct modeop op_jvc[] = {
	{M_REL, 0x50},
	{M_REL, 0x70},
	{0, 0}
};
static struct modeop op_jvs[] = {
	{M_REL, 0x70},
	{M_REL, 0x50},
	{0, 0}
};
static struct modeop op_lda[] = {
	{M_IMM, 0xa9}, {M_DIRECT, 0xa5}, {M_DIRX, 0xb5},
	{M_DIRIND, 0xb2}, {M_DIRIDXIND, 0xa1}, {M_DIRINDIDX, 0xb1},
	{M_DIRINDLONG, 0xa7}, {M_DIRINDLONGIDX, 0xb7}, {M_ABS, 0xad},
	{M_ABSX, 0xbd}, {M_ABSY, 0xb9}, {M_ABSLONG, 0xaf},
	{M_ABSLONGX, 0xbf}, {M_STACKREL, 0xa3}, {M_STACKRELINDIDX, 0xb3},
	{0, 0}
};
static struct modeop op_ldx[] = {
	{M_IMM, 0xa2}, {M_DIRECT, 0xa6}, {M_DIRY, 0xb6},
	{M_ABS, 0xae}, {M_ABSY, 0xbe},
	{0, 0}
};
static struct modeop op_ldy[] = {
	{M_IMM, 0xa0}, {M_DIRECT, 0xa4}, {M_DIRX, 0xb4},
	{M_ABS, 0xac}, {M_ABSX, 0xbc},
	{0, 0}
};
static struct modeop op_lsr[] = {
	{M_DIRECT, 0x46}, {M_DIRX, 0x56}, {M_ABS, 0x4e},
	{M_ABSX, 0x5e},
	{0, 0}
};
static struct modeop op_mvn[] = {
	{M_ABS, 0x54},
	{0, 0}
};
static struct modeop op_mvp[] = {
	{M_ABS, 0x44},
	{0, 0}
};
static struct modeop op_nop[] = {
	{M_IMPL, 0xea},
	{0, 0}
};
static struct modeop op_ora[] = {
	{M_IMM, 0x09}, {M_DIRECT, 0x05}, {M_DIRX, 0x15},
	{M_DIRIND, 0x12}, {M_DIRIDXIND, 0x01}, {M_DIRINDIDX, 0x11},
	{M_DIRINDLONG, 0x07}, {M_DIRINDLONGIDX, 0x17}, {M_ABS, 0x0d},
	{M_ABSX, 0x1d}, {M_ABSY, 0x19}, {M_ABSLONG, 0x0f},
	{M_ABSLONGX, 0x1f}, {M_STACKREL, 0x03}, {M_STACKRELINDIDX, 0x13},
	{0, 0}
};
static struct modeop op_pea[] = {
	{M_ABS, 0xf4},
	{0, 0}
};
static struct modeop op_pei[] = {
	{M_DIRIND, 0xd4},
	{0, 0}
};
static struct modeop op_per[] = {
	{M_ABSLONG, 0x62},
	{0, 0}
};
static struct modeop op_pha[] = {
	{M_IMPL, 0x48},
	{0, 0}
};
static struct modeop op_phb[] = {
	{M_IMPL, 0x8b},
	{0, 0}
};
static struct modeop op_phd[] = {
	{M_IMPL, 0x0b},
	{0, 0}
};
static struct modeop op_phk[] = {
	{M_IMPL, 0x4b},
	{0, 0}
};
static struct modeop op_php[] = {
	{M_IMPL, 0x08},
	{0, 0}
};
static struct modeop op_phx[] = {
	{M_IMPL, 0xda},
	{0, 0}
};
static struct modeop op_phy[] = {
	{M_IMPL, 0x5a},
	{0, 0}
};
static struct modeop op_pla[] = {
	{M_IMPL, 0x68},
	{0, 0}
};
static struct modeop op_plb[] = {
	{M_IMPL, 0xab},
	{0, 0}
};
static struct modeop op_pld[] = {
	{M_IMPL, 0x2b},
	{0, 0}
};
static struct modeop op_plp[] = {
	{M_IMPL, 0x28},
	{0, 0}
};
static struct modeop op_plx[] = {
	{M_IMPL, 0xfa},
	{0, 0}
};
static struct modeop op_ply[] = {
	{M_IMPL, 0x7a},
	{0, 0}
};
static struct modeop op_rep[] = {
	{M_IMM, 0xc2},
	{0, 0}
};
static struct modeop op_rol[] = {
	{M_ACC, 0x2a}, {M_DIRECT, 0xe6}, {M_DIRX, 0x36},
	{M_ABS, 0x2e}, {M_ABSX, 0x3e},
	{0, 0}
};
static struct modeop op_ror[] = {
	{M_ACC, 0x6a}, {M_DIRECT, 0x66}, {M_DIRX, 0x76},
	{M_ABS, 0x6e}, {M_ABSX, 0x7e},
	{0, 0}
};
static struct modeop op_rti[] = {
	{M_IMPL, 0x40},
	{0, 0}
};
static struct modeop op_rts[] = {
	{M_IMPL, 0x60},
	{0, 0}
};
static struct modeop op_sbc[] = {
	{M_IMM, 0xe9}, {M_DIRECT, 0xe5}, {M_DIRX, 0xf5},
	{M_DIRIND, 0xf2}, {M_DIRIDXIND, 0xe1}, {M_DIRINDIDX, 0xf1},
	{M_DIRINDLONG, 0xe7}, {M_DIRINDLONGIDX, 0xf7}, {M_ABS, 0xed},
	{M_ABSX, 0xfd}, {M_ABSY, 0xf9}, {M_ABSLONG, 0xef},
	{M_ABSLONGX, 0xff}, {M_STACKREL, 0xe3}, {M_STACKRELINDIDX, 0xf3},
	{0, 0}
};
static struct modeop op_sec[] = {
	{M_IMPL, 0x38},
	{0, 0}
};
static struct modeop op_sed[] = {
	{M_IMPL, 0xf8},
	{0, 0}
};
static struct modeop op_sei[] = {
	{M_IMPL, 0x78},
	{0, 0}
};
static struct modeop op_sep[] = {
	{M_IMM, 0xe2},
	{0, 0}
};
static struct modeop op_sta[] = {
	{M_DIRECT, 0x85}, {M_DIRX, 0x95},
	{M_DIRIND, 0x92}, {M_DIRIDXIND, 0x81}, {M_DIRINDIDX, 0x91},
	{M_DIRINDLONG, 0x87}, {M_DIRINDLONGIDX, 0x97}, {M_ABS, 0x8d},
	{M_ABSX, 0x9d}, {M_ABSY, 0x99}, {M_ABSLONG, 0x8f},
	{M_ABSLONGX, 0x9f}, {M_STACKREL, 0x83}, {M_STACKRELINDIDX, 0x93},
	{0, 0}
};
static struct modeop op_stp[] = {
	{M_IMPL, 0xdb},
	{0, 0}
};
static struct modeop op_stx[] = {
	{M_DIRECT, 0x86}, {M_DIRY, 0x96}, {M_ABS, 0x8e},
	{0, 0}
};
static struct modeop op_sty[] = {
	{M_DIRECT, 0x84}, {M_DIRX, 0x94}, {M_ABS, 0x8c},
	{0, 0}
};
static struct modeop op_stz[] = {
	{M_DIRECT, 0x64}, {M_DIRX, 0x74}, {M_ABS, 0x9c},
	{M_ABSX, 0x9e},
	{0, 0}
};
static struct modeop op_tax[] = {
	{M_IMPL, 0xaa},
	{0, 0}
};
static struct modeop op_tay[] = {
	{M_IMPL, 0xa8},
	{0, 0}
};
static struct modeop op_tcd[] = {
	{M_IMPL, 0x5b},
	{0, 0}
};
static struct modeop op_tdc[] = {
	{M_IMPL, 0x7b},
	{0, 0}
};
static struct modeop op_trb[] = {
	{M_DIRECT, 0x14}, {M_ABS, 0x1c},
	{0, 0}
};
static struct modeop op_tsb[] = {
	{M_DIRECT, 0x04}, {M_ABS, 0x0c},
	{0, 0}
};
static struct modeop op_tsc[] = {
	{M_IMPL, 0x3b},
	{0, 0}
};
static struct modeop op_tsx[] = {
	{M_IMPL, 0xba},
	{0, 0}
};
static struct modeop op_txa[] = {
	{M_IMPL, 0x8a},
	{0, 0}
};
static struct modeop op_txs[] = {
	{M_IMPL, 0x9a},
	{0, 0}
};
static struct modeop op_txy[] = {
	{M_IMPL, 0x9b},
	{0, 0}
};
static struct modeop op_tya[] = {
	{M_IMPL, 0x98},
	{0, 0}
};
static struct modeop op_wai[] = {
	{M_IMPL, 0xcb},
	{0, 0}
};
static struct modeop op_xba[] = {
	{M_IMPL, 0xeb},
	{0, 0}
};
static struct modeop op_xce[] = {
	{M_IMPL, 0xfb},
	{0, 0}
};

struct opcode optab[] = {
	"adc", 0x0, op_adc,
	"and", 0x0, op_and,
	"asl", 0x0, op_asl,
	"bcc", F_BRANCH, op_bcc,
	"bcs", F_BRANCH, op_bcs,
	"beq", F_BRANCH, op_beq,
	"bit", F_BRANCH, op_bit,
	"bmi", F_BRANCH, op_bmi,
	"bne", F_BRANCH, op_bne,
	"bpl", F_BRANCH, op_bpl,
	"bra", F_BRANCH, op_bra,
	"brk", 0x0, op_brk,
	"brl", F_BRANCHL, op_brl,
	"bvc", F_BRANCH, op_bvc,
	"bvs", F_BRANCH, op_bvs,
	"clc", 0x0, op_clc,
	"cld", 0x0, op_cld,
	"cli", 0x0, op_cli,
	"clv", 0x0, op_clv,
	"cmp", 0x0, op_cmp,
	"cop", 0x0, op_cop,
	"cpx", 0x0, op_cpx,
	"cpy", 0x0, op_cpy,
	"dec", 0x0, op_dec,
	"dex", 0x0, op_dex,
	"dey", 0x0, op_dey,
	"eor", 0x0, op_eor,
	"inc", 0x0, op_inc,
	"inx", 0x0, op_inx,
	"iny", 0x0, op_iny,
	"jcc", F_PSEUDOB, op_jcc,
	"jcs", F_PSEUDOB, op_jcs,
	"jeq", F_PSEUDOB, op_jeq,
	"jmi", F_PSEUDOB, op_jmi,
	"jml", 0x0, op_jml,
	"jmp", 0x0, op_jmp,
	"jne", F_PSEUDOB, op_jne,
	"jpl", F_PSEUDOB, op_jpl,
	"jsl", F_JSL, op_jsl,
	"jsr", 0x0, op_jsr,
	"jvc", F_PSEUDOB, op_jvc,
	"jvs", F_PSEUDOB, op_jvs,
	"lda", 0x0, op_lda,
	"ldx", 0x0, op_ldx,
	"ldy", 0x0, op_ldy,
	"lsr", 0x0, op_lsr,
	"mvn", 0x0, op_mvn,
	"mvp", 0x0, op_mvp,
	"nop", 0x0, op_nop,
	"ora", 0x0, op_ora,
	"pea", 0x0, op_pea,
	"pei", 0x0, op_pei,
	"per", 0x0, op_per,
	"pha", 0x0, op_pha,
	"phb", 0x0, op_phb,
	"phd", 0x0, op_phd,
	"phk", 0x0, op_phk,
	"php", 0x0, op_php,
	"phx", 0x0, op_phx,
	"phy", 0x0, op_phy,
	"pla", 0x0, op_pla,
	"plb", 0x0, op_plb,
	"pld", 0x0, op_pld,
	"plp", 0x0, op_plp,
	"plx", 0x0, op_plx,
	"ply", 0x0, op_ply,
	"rep", 0x0, op_rep,
	"rol", 0x0, op_rol,
	"ror", 0x0, op_ror,
	"rti", 0x0, op_rti,
	"rts", 0x0, op_rts,
	"sbc", 0x0, op_sbc,
	"sec", 0x0, op_sec,
	"sed", 0x0, op_sed,
	"sei", 0x0, op_sei,
	"sep", 0x0, op_sep,
	"sta", 0x0, op_sta,
	"stp", 0x0, op_stp,
	"stx", 0x0, op_stx,
	"sty", 0x0, op_sty,
	"stz", 0x0, op_stz,
	"tax", 0x0, op_tax,
	"tay", 0x0, op_tay,
	"tcd", 0x0, op_tcd,
	"tdc", 0x0, op_tdc,
	"trb", 0x0, op_trb,
	"tsb", 0x0, op_tsb,
	"tsc", 0x0, op_tsc,
	"tsx", 0x0, op_tsx,
	"txa", 0x0, op_txa,
	"txs", 0x0, op_txs,
	"txy", 0x0, op_txy,
	"tya", 0x0, op_tya,
	"wai", 0x0, op_wai,
	"xba", 0x0, op_xba,
	"xce", 0x0, op_xce,
};
#define NOPCODES	(sizeof(optab) / sizeof(optab[0]))

isopcode(char *str)
{
	int l, r, c, m;
	l = 0;
	r = NOPCODES - 1;
	while (l <= r) {
		m = (l + r) / 2;
		if ((c = strcmp(str, optab[m].mne)) == 0)
			return m;
		else if (c < 0)
			r = m - 1;
		else
			l = m + 1;
	}
	return -1;
}

oplookup(int n, int mode)
{
	int i;
	for(i = 0; optab[n].modes[i].mode ;i++)
		if (optab[n].modes[i].mode == mode)
			return i;
	return -1;
}
