/*
 */
#include <stdio.h>
#include "nodes.h"

#define HSIZE	101

struct sym *symtab[HSIZE];

hash(char *str)
{
	int ret = 0;
	while (*str)
		ret = (*str++ + ret) % HSIZE;
	return ret;
}

struct sym *
lookup(char *str)
{
	int slot = hash(str);
	register struct sym *p;
	for(p = symtab[slot]; p != NULL ;p = p->next)
		if (strcmp(str, p->name) == 0)
			break;
	return p;
}

struct sym *
install(char *str, struct segment *cs, int defined)
{
	int slot = hash(str);
	register struct sym *p;
	for(p = symtab[slot]; p != NULL ;p = p->next)
		if (strcmp(str, p->name) == 0)
			break;
	if (p == NULL) {
		p = (struct sym *)xmalloc(sizeof(struct sym));
		p->name = (char *)xmalloc(strlen(str)+1);
		strcpy(p->name, str);
		p->exported = 0;
		p->next = symtab[slot];
		symtab[slot] = p;
	}
	p->val = cs->dot;
	p->seg = cs;
	p->defined = defined;
	return p;
}

everysym(func)
int (*func)();
{
	int i;
	struct sym *s;
	for(i = 0; i < HSIZE ;i++)
		for(s = symtab[i]; s != NULL ;s = s->next)
			func(s);
}
