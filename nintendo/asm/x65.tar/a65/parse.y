%{
/*
 * Parser for assembler input files.  Yacc may seem like
 * overkill for an assembler but it made the expression
 * stuff trivial...
 */

#include <stdio.h>
#include <ctype.h>
#include "opcodes.h"
#include "nodes.h"

int lastop;
int lineno = 1;

%}

%union {
	struct node *e;
	char str[MAXSYMLEN];
	int ival;
};

%token tBYTE tLSHIFT tRSHIFT tGLOBL tSPACE tWORD tDOT tTEXT tDATA tBSS
%token <str> tIDENT
%token <ival> tNUMBER
%token <ival> tOPCODE tBRANCHOP tJSL tBRL

%type <e> expr

%left '|'
%left '^'
%left '&'
%left tLSHIFT tRSHIFT
%left '+' '-'
%left '*' '/' '%'
%right tUNARY '!' '~'

%start lines

%%

lines	:	line
	|	line lines
	;

line	:	eoln
	|	instruction eoln
	;

instruction:	label rest
	|	label
	|	rest
	;

label	:	tIDENT ':'
			{ install($1, curseg, 1); }
	;

rest	:	tOPCODE '#' expr
			{ insn($1, $3, M_IMM, 2); }
	|	tOPCODE '#' expr ':' 'b'
			{ insn($1, $3, M_IMM, 1); }
	|	tOPCODE expr
			{ insn($1, $2, M_ABS, 2); }
	|	tOPCODE expr ':' 'l'
			{ insn($1, $2, M_ABSLONG, 3); }
	|	tOPCODE expr ':' 'd'
			{ insn($1, $2, M_DIRECT, 1); }
	|	tOPCODE 'a'
			{ insn($1, NULL, M_ACC, 0); }
	|	tOPCODE /* implied */
			{ insn($1, NULL, M_IMPL, 0); }
	|	tOPCODE '(' expr ')' ',' 'y'
			{ insn($1, $3, M_DIRINDIDX, 1); }
	|	tOPCODE '[' expr ']' ',' 'y'
			{ insn($1, $3, M_DIRINDLONGIDX, 1); }
	|	tOPCODE '(' expr ':' 'd' ',' 'x' ')'
			{ insn($1, $3, M_DIRIDXIND, 1); }
	|	tOPCODE expr ':' 'd' ',' 'x'
			{ insn($1, $2, M_DIRX, 1); }
	|	tOPCODE expr ':' 'd' ',' 'y'
			{ insn($1, $2, M_DIRY, 1); }
	|	tOPCODE expr ',' 'x'
			{ insn($1, $2, M_ABSX, 2); }
	|	tOPCODE expr ':' 'l' ',' 'x'
			{ insn($1, $2, M_ABSLONGX, 3); }
	|	tOPCODE expr ',' 'y'
			{ insn($1, $2, M_ABSY, 2); }
	|	tBRANCHOP expr
			{ insn($1, makenode('-', $2,
				makesym(constsym(curseg, curseg->dot+2))),
					M_REL, 1); }
	|	tJSL expr
			{ insn($1, $2, M_ABSLONG, 3); }
	|	tBRL expr
			{ insn($1, makenode('-', $2,
				makesym(constsym(curseg, curseg->dot+3))),
					M_RELLONG, 2); }
	|	tOPCODE '(' expr ')'
			{ insn($1, $3, M_ABSIND, 2); }
	|	tOPCODE '(' expr ':' 'd' ')'
			{ insn($1, $3, M_DIRIND, 1); }
	|	tOPCODE '[' expr ']'
			{ insn($1, $3, M_DIRINDLONG, 1); }
	|	tOPCODE '(' expr ',' 'x' ')'
			{ insn($1, $3, M_ABSIDXIND, 2); }
	|	tOPCODE expr ',' 's'
			{ insn($1, $2, M_STACKREL, 1); }
	|	tOPCODE '(' expr ',' 's' ')' ',' 'y'
			{ insn($1, $3, M_STACKRELINDIDX, 1); }
	|	pseudo_op
	;

eoln	:	';'
	|	'\n'
			{ lineno++; }
	;

expr	:	'{' expr '}'
			{ $$ = $2; }
	|	expr '|' expr
			{ $$ = makenode('|', $1, $3); }
	|	expr '^' expr
			{ $$ = makenode('^', $1, $3); }
	|	expr '&' expr
			{ $$ = makenode('&', $1, $3); }
	|	expr tLSHIFT expr
			{ $$ = makenode(tLSHIFT, $1, $3); }
	|	expr tRSHIFT expr
			{ $$ = makenode(tRSHIFT, $1, $3); }
	|	expr '+' expr
			{ $$ = makenode('+', $1, $3); }
	|	expr '-' expr
			{ $$ = makenode('-', $1, $3); }
	|	expr '*' expr
			{ $$ = makenode('*', $1, $3); }
	|	expr '/' expr
			{ $$ = makenode('/', $1, $3); }
	|	expr '%' expr
			{ $$ = makenode('%', $1, $3); }
	|	'-' expr %prec tUNARY
			{ $$ = makenode('-', $2, NULL); }
	|	'!' expr
			{ $$ = makenode('!', $2, NULL); }
	|	'~' expr
			{ $$ = makenode('~', $2, NULL); }
	|	tNUMBER
			{ $$ = makeconst($1); }
	|	tIDENT
			{ struct sym *s;
			  if ((s = lookup($1)) != NULL)
				$$ = makesym(s);
			  else
			  	$$ = makesym(install($1, curseg, 0));
			}
	|	tDOT
			{ $$ = makesym(constsym(curseg, curseg->dot)); }
	;

pseudo_op:	byte_list
	|	word_list
	|	globl_list
	|	tTEXT
			{ curseg = &textseg; }
	|	tDATA
			{ curseg = &dataseg; }
	|	tBSS
			{ curseg = &bssseg; }
	|	tSPACE expr
			{ struct etype e = eval($2);
			  if (!e.seg)
				curseg->dot += eval($2).value;
			  else
			  	yyerror(".space must take constant arg");
			  freetree($2);
		   	}
	;

word_list:	tWORD expr
			{ if (curseg->mem) {
				struct etype e = eval($2);
				if (e.seg)
					addreloc(curseg, e.seg, curseg->dot, 2);
				patchbytes(curseg, curseg->dot, 2, e.value);
				curseg->dot += 2;
			  }
			  freetree($2);
		  	}
	|	word_list ',' expr
			{ if (curseg->mem) {
				struct etype e = eval($3);
				if (e.seg)
					addreloc(curseg, e.seg, curseg->dot, 2);
				patchbytes(curseg, curseg->dot, 2, e.value);
				curseg->dot += 2;
			  }
			  freetree($3);
		  	}
	;

byte_list:	tBYTE expr
			{ if (curseg->mem) {
				curseg->mem[curseg->dot++] = eval($2).value;
			  }
			  freetree($2);
			}
	|	byte_list ',' expr
			{ if (curseg->mem) {
				curseg->mem[curseg->dot++] = eval($3).value;
			  }
			  freetree($3);
			}
	;

globl_list:	tGLOBL tIDENT
			{ exportname($2); }
	|	globl_list ',' tIDENT
			{ exportname($3); }
	;

%%

extern FILE *infile;

struct {
	char *name;
	int token;
} keytab[] = {
	".",	tDOT,
	".bss", tBSS,
	".byte", tBYTE,
	".data", tDATA,
	".globl", tGLOBL,
	".space", tSPACE,
	".text", tTEXT,
	".word", tWORD,
	"a",	'a',
	"b",	'b',
	"d",	'd',
	"l",	'l',
	"s",	's',
	"x",	'x',
	"y",	'y',
	NULL,	-1,
};
	
yylex()
{
	int c, i;
	while ((c = getc(infile)) != EOF && (c == ' ' || c == '\t'))
		;
	if (c == ';')
		while ((c = getc(infile)) != EOF && c != '\n')
			;
	if (c == '.' || c == '_' || isalpha(c)) {
		yylval.str[0] = c; i = 1;
		while ((c = getc(infile)) != EOF &&
				(isalnum(c) || c == '_') && i < MAXSYMLEN-1)
			yylval.str[i++] = c;
		if (i == MAXSYMLEN-1) {		/* skip rest... */
			while ((c = getc(infile)) != EOF &&
					(isalnum(c) || c == '_'))
				;
		}
		ungetc(c, infile);
		yylval.str[i] = '\0';
		if ((i = isopcode(yylval.str)) >= 0) {
			yylval.ival = i;
			if (optab[i].flags & F_BRANCH)
				return tBRANCHOP;
			else if (optab[i].flags & F_BRANCHL)
				return tBRL;
			else if (optab[i].flags & F_JSL)
				return tJSL;
			else
				return tOPCODE;
		}
		for(i = 0; keytab[i].name != NULL ;i++)
			if (strcmp(yylval.str, keytab[i].name) == 0)
				return keytab[i].token;
		return tIDENT;
	}
	if (c == '$') {		/* hex constant */
		while ((c = getc(infile)) != EOF && isspace(c))
			;
		yylval.ival = 0;
		while (isxdigit(c)) {
			if (c >= '0' && c <= '9')
				yylval.ival = 16*yylval.ival + c - '0';
			else if (c >= 'a' && c <= 'f')
				yylval.ival = 16*yylval.ival + c - 'a' + 10;
			else if (c >= 'A' && c <= 'F')
				yylval.ival = 16*yylval.ival + c - 'A' + 10;
			c = getc(infile);
		}
		ungetc(c, infile);
		return tNUMBER;
	}
	if (c == '%') {		/* binary constant */
		while ((c = getc(infile)) != EOF && isspace(c))
			;
		yylval.ival = 0;
		while (c == '0' || c == '1') {
			yylval.ival = (yylval.ival << 1) + c - '0';
			c = getc(infile);
		}
		ungetc(c, infile);
		return tNUMBER;
	}
	if (isdigit(c)) {	/* decimal constant */
		yylval.ival = c - '0';
		while ((c = getc(infile)) != EOF && isdigit(c))
			yylval.ival = 10*yylval.ival + c - '0';
		ungetc(c, infile);
		return tNUMBER;
	}
	if (c == '<') {
		c = getc(infile);
		if (c == '<') return tLSHIFT;
		ungetc(c, infile);
		return '<';
	}
	if (c == '>') {
		c = getc(infile);
		if (c == '>') return tRSHIFT;
		ungetc(c, infile);
		return '>';
	}
	return c;
}

yyerror(char *str)
{
	fprintf(stderr, "Line %d: %s\n", lineno, str);
}

struct node *
makenode(int op, struct node *l, struct node *r)
{
	struct node *p = (struct node *)xmalloc(sizeof(struct node));
	p->n_op = op;
	p->n_left = l;
	p->n_right = r;
	return p;
}

struct node *
makesym(struct sym *s)
{
	struct node *p = (struct node *)xmalloc(sizeof(struct node));
	p->n_op = tIDENT;
	p->n_sym = s;
	return p;
}

struct sym *
constsym(struct segment *cs, int value)
{
	struct sym *s = (struct sym *)xmalloc(sizeof(struct sym));
	s->name = "branch";
	s->val = value;
	s->seg = cs;
	s->defined = 1;
	s->exported = 0;
	s->next = NULL;
}

struct node *
makeconst(int val)
{
	struct node *p = (struct node *)xmalloc(sizeof(struct node));
	p->n_op = tNUMBER;
	p->n_val = val;
	return p;
}

exportname(char *name)
{
	struct sym *s;
	if ((s = lookup(name)) == NULL)
		s = install(name, curseg, 0);
	s->exported = 1;
}
