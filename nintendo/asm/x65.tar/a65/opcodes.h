/*
 * The 24 modes directly from WDCs book.
 */

#define M_IMM		1
#define M_ABS		2
#define M_ABSLONG	3
#define M_DIRECT	4
#define M_ACC		5
#define M_IMPL		6
#define M_DIRINDIDX	7
#define M_DIRINDLONGIDX	8
#define M_DIRIDXIND	9
#define M_DIRX		10
#define M_DIRY		11
#define M_ABSX		12
#define M_ABSLONGX	13
#define M_ABSY		14
#define M_REL		15
#define M_RELLONG	16
#define M_ABSIND	17
#define M_DIRIND	18
#define M_DIRINDLONG	19
#define M_ABSIDXIND	20
#define M_STACK		21
#define M_STACKREL	22
#define M_STACKRELINDIDX 23
#define M_BLOCK		24

/*
 * Each opcode contains a list of modeop structures to match
 * opcode-mnemonic/operand-type/generated-opcode.
 */
struct modeop {
	unsigned char mode;
	unsigned char opcode;
};

struct opcode {
	char *mne;
	unsigned char flags;
	struct modeop *modes;
};

