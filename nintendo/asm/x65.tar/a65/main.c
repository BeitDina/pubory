/*
 * A simple assembler for the 65816...
 */
#include <stdio.h>
#include <stdlib.h>
#include "nodes.h"
#include "y.tab.h"

#define MAXMEM		(1024*64)

FILE *infile = stdin;
int verbose = 0;
int debug = 0;
struct exec65 a;
FILE *fo;
char *outfile = "a65.out";

char textmem[MAXMEM], datamem[MAXMEM];
struct segment textseg = { textmem, 0, S_TEXT };
struct segment dataseg = { datamem, 0, S_DATA };
struct segment bssseg = { NULL, 0, S_BSS };
struct segment *curseg = &textseg;

#ifdef YYDEBUG
extern int yydebug;
#endif

main(int argc, char **argv)
{
	extern int writesyms(), countsyms();
	int c;
	while ((c = getopt(argc, argv, "vdo:")) != EOF)
		switch (c) {
		case 'o':
			outfile = optarg;
			break;
		case 'v':
			verbose++;
			break;
		case 'd':
			debug++;
#ifdef YYDEBUG
			yydebug++;
#endif
			break;
		}
	if (optind < argc)
		infile = fopen(argv[optind], "r");

	/*
	 * Since eval() is recursive we set this up to catch cases
	 * where undefined identifiers are used.  It's also used by
	 * pass2().
	 */
	if (setjmp(evaljmp)) {
		fprintf(stderr, "Line %d: Cannot evaluate expression\n", lineno);
		exit(1);
	}

	yyparse(0);
	pass2();

	if (textseg.dot || dataseg.dot || bssseg.dot) {
		a.e_magic = RMAGIC;
		a.e_entry = 0;
		a.e_text = textseg.dot;
		a.e_data = dataseg.dot;
		a.e_bss = bssseg.dot;
		a.e_nreloc = countrelocs();
		a.e_nsym = 0;
		everysym(countsyms);
		a.e_nsym += countexterns();
		if ((fo = fopen(outfile, "w")) != NULL) {
			fwrite(&a, sizeof(a), 1, fo);
			fwrite(textseg.mem, textseg.dot, 1, fo);
			fwrite(dataseg.mem, dataseg.dot, 1, fo);
			writerelocs();
			everysym(writesyms);
			writeexterns();
			fclose(fo);
		} else {
			fprintf(stderr, "Can't create %s\n", outfile);
		}
	}
	printf("%d bytes used\n", stats.memused);
}

/*
 * If a symbol was referenced but not defined anywhere then
 * the patchlist set up for pass2 will have p->resolved == 2.
 * We make S_UNDEF symbol table entries for them here...
 */
writeexterns()
{
	struct patch *p;
	struct sym65 s;
	for(p = patchlist; p != NULL ;p = p->next)
		if (p->resolved == 2) {
			strcpy(s.s_name, p->etree->n_sym->name);
			s.s_value = p->addr;
			s.s_size = p->size;
			s.s_type = p->seg->type|S_UNDEF;
			fwrite(&s, sizeof(s), 1, fo);
		}
}

/*
 * I didn't want to seek around in the output file so we need
 * these to set up a.nsym correctly.
 */
countexterns()
{
	struct patch *p;
	int n = 0;
	for(p = patchlist; p != NULL ;p = p->next)
		if (p->resolved == 2)
			n++;
	return n;
}

countsyms(struct sym *s)
{
	if (s->exported && s->defined) {
		a.e_nsym++;
	}
}

writesyms(struct sym *s)
{
	struct sym65 p;
	if (s->exported && s->defined) {
		strcpy(p.s_name, s->name);
		p.s_value = s->val;
		p.s_size = 0;
		p.s_type = s->seg->type;
		fwrite(&p, sizeof(p), 1, fo);
	}
}

countrelocs()
{
	struct reloc *r;
	int n = 0;
	for(r = reloclist; r != NULL ;r = r->next)
		n++;
	return n;
}

writerelocs()
{
	struct reloc *r;
	struct reloc65 s;
	for(r = reloclist; r != NULL ;r = r->next) {
		s.r_addr = r->addr;
		s.r_size = r->size;
		s.r_seg = r->seg;
		s.r_targ = r->targ;
		fwrite(&s, sizeof(s), 1, fo);
	}
}

void *
xmalloc(int nbytes)
{
	void *ret = malloc(nbytes);
	if (ret == NULL) {
		fprintf(stderr, "Out of memory\n");
		exit(1);
	}
	stats.memused += nbytes;
	return ret;
}

void
xfree(void *ptr, int nbytes)
{
	free(ptr);
	stats.memused -= nbytes;
}
