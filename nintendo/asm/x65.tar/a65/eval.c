/*
 * Evaluate the expression tree, return the value as
 * well as an indication of its type (constant or address).
 * This is nessary so that things like:
 *	lda	#label+2
 * will generate a relocation entry while
 *	lda	#label1-label2
 * wont.
 * Sorry about passing structures around...
 */
#include <stdio.h>
#include "nodes.h"
#include "y.tab.h"

#define binop(op) \
	a = eval(e->n_left); b = eval(e->n_right); \
	if (a.seg && !b.seg) { \
		r.seg = a.seg; \
	} else if (!a.seg && b.seg) { \
		r.seg = b.seg; \
	} else { \
		if ((a.seg && b.seg) && a.seg != b.seg) \
			yyerror("Address arith must be in same segment"); \
		r.seg = NULL; \
	} \
	r.value = a.value op b.value; \
	return r

struct etype
eval(struct node *e)
{
	struct etype r, a, b;
	int t;
	if (e) {
		switch(e->n_op) {
		case tNUMBER:
			r.seg = NULL;
			r.value = e->n_val;
			return r;
		case tIDENT:
			if (!e->n_sym->defined)
				longjmp(evaljmp, 1);
			r.seg = e->n_sym->seg;
			r.value = e->n_sym->val;
			return r;
		case '|': binop(|);
		case '^': binop(^);
		case '&': binop(&);
		case tLSHIFT: binop(<<);
		case tRSHIFT: binop(>>);
		case '+': binop(+);
		case '-':
			if (e->n_right == NULL) {
				a = eval(e->n_left);
				r.value = -a.value;
				r.seg = a.seg;
				return r;
			} else {
				binop(-);
			}
		case '*': binop(*);
		case '/': binop(/);
		case '%': binop(%);
		case '!':
			a = eval(e->n_left);
			r.value = !a.value;
			r.seg = a.seg;
			return r;
		case '~':
			a = eval(e->n_left);
			r.value = ~a.value;
			r.seg = a.seg;
			return r;
		default:
			fprintf(stderr, "Unknown op in eval, %d\n", e->n_op);
			exit(1);
		}
	} else {
		fprintf(stderr, "Eval called with NULL!\n");
		exit(1);
	}
}

void
freetree(struct node *e)
{
	if (e) {
		if (e->n_op == tNUMBER || e->n_op == tIDENT)
			xfree((void *)e, sizeof(*e));
		else {
			freetree(e->n_left);
			freetree(e->n_right);
		}
	}
}
