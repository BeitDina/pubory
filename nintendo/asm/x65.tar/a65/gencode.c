/*
 */
#include <stdio.h>
#include "opcodes.h"
#include "nodes.h"
#include "y.tab.h"

struct patch *patchlist = NULL;
struct reloc *reloclist = NULL;

addpatch(struct segment *seg, int addr, int size, struct node *etree)
{
	struct patch *p = (struct patch *)xmalloc(sizeof(struct patch));
	extern int lineno;
	p->addr = addr;
	p->seg = seg;
	p->size = size;
	p->etree = etree;
	p->lineno = lineno;	/* so pass2 gives good messages */
	p->resolved = 0;
	p->next = patchlist;
	patchlist = p;
}

void
addreloc(struct segment *srcseg, struct segment *dstseg, int addr, int size)
{
	struct reloc *r = (struct reloc *)xmalloc(sizeof(struct reloc));
	r->addr = addr;
	r->seg = srcseg->type;
	r->targ = dstseg->type;
	r->size = size;
	r->next = reloclist;
	reloclist = r;
}

insn(int op, struct node *etree, int mode, int size)
{
	int m;
	if ((m = oplookup(op, mode)) >= 0) {
		curseg->mem[curseg->dot] = optab[op].modes[m].opcode;
	} else {
		yyerror("Invalid mode");
	}
	if (size && etree) {
		addpatch(curseg, curseg->dot+1, size, etree);
	}
	curseg->dot += size+1;
}

pass2()
{
	struct patch *p;
	struct etype e;
	for(p = patchlist; p != NULL ;p = p->next) {
		if (setjmp(evaljmp)) {	/* eval failed... */
			if (p->etree->n_op != tIDENT) {
fprintf(stderr, "Line %d: Complex exprs not allowed on externs\n", p->lineno);
			} else {
				p->etree->n_sym->exported++;
				p->resolved = 2;
			}
			continue;
		} else {
			e = eval(p->etree);
			p->resolved++;
			patchbytes(p->seg, p->addr, p->size, e.value);
		}
	}
}

patchbytes(struct segment *seg, int addr, int len, int value)
{
	int i;
	for(i = 0; i < len ;i++) {
		seg->mem[addr+i] = value % 256;
		value /= 256;
	}
}
