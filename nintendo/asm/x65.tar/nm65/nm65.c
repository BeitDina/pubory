/*
 * Dump exec header, relocation table and symbol table for
 * an x65 object file...
 */
#include <stdio.h>
#include <stdlib.h>
#include "exec65.h"

char *segnames[] = { "<unknown>", "<text>", "<data>", "<bss>" };
int hflag, tflag, dflag, sflag, rflag;

main(int argc, char **argv)
{
	int c;
	while ((c = getopt(argc, argv, "htdr")) != EOF)
		switch (c) {
		case 'h':
			hflag++;
			break;
		case 't':
			tflag++;
			break;
		case 'd':
			dflag++;
			break;
		case 'r':
			rflag++;
			break;
		}

	if (!(hflag || tflag || dflag || rflag))
		sflag++;

	while (optind < argc)
		process(argv[optind++]);
}

process(char *name)
{
	struct reloc65 r;
	struct exec65 a;
	struct sym65 s;
	char *txt = NULL, *dat = NULL;
	int i, v;
	FILE *fi;

	if ((fi = fopen(name, "r")) == NULL) {
		fprintf(stderr, "Can't open %s\n", name);
		exit(1);
	}
	fread(&a, sizeof(a), 1, fi);
	if (a.e_magic != RMAGIC && a.e_magic != EMAGIC) {
		fprintf(stderr, "Invalid x65 header\n");
		exit(1);
	}
	if (hflag) {
		printf("Exec header:\n");
		printf("\tentry point=0x%x\n", a.e_entry);
		printf("\ttext size=%d\n", a.e_text);
		printf("\tdata size=%d\n", a.e_data);
		printf("\tbss size=%d\n", a.e_bss);
		printf("\tnreloc=%d\n", a.e_nreloc);
		printf("\tnsym=%d\n", a.e_nsym);
	}
	if (a.e_text) {
		txt = (char *)malloc(a.e_text);
		fread(txt, a.e_text, 1, fi);
	}
	if (tflag && a.e_text) {
		printf("Text section:\n");
		dumpbytes(txt, a.e_text, a.e_entry);
	}
	if (a.e_data) {
		dat = (char *)malloc(a.e_data);
		fread(dat, a.e_data, 1, fi);
	}
	if (dflag && a.e_data) {
		printf("Data section:\n");
		dumpbytes(dat, a.e_data, a.e_entry+a.e_text);
	}
	if (rflag && a.e_nreloc) {
		printf("Relocation table:\n");
		fseek(fi, sizeof(a)+a.e_text+a.e_data, 0);
		for(i = 0; i < a.e_nreloc ;i++) {
			if (fread(&r, sizeof(r), 1, fi) != 1) {
				fprintf(stderr, "Truncated file\n");
				exit(1);
			}
			printf("\t%8s(0x%04x)\t%8s",
				segnames[r.r_seg], r.r_addr, segnames[r.r_targ]);
			if (r.r_seg == S_TEXT && txt) {
				v = getbytes(&txt[r.r_addr], r.r_size);
				printf("(0x%04x)", v);
			} else if (r.r_seg == S_DATA && dat) {
				v = getbytes(&dat[r.r_addr], r.r_size);
				printf("(0x%04x)", v);
			}
			printf("\tsize=%d\n", r.r_size);
		}
	}
	if (sflag && a.e_nsym) {
		printf("Symbol table:\n");
		fseek(fi, sizeof(a)+a.e_text+a.e_data+a.e_nreloc*sizeof(r), 0);
		for(i = 0; i < a.e_nsym ;i++) {
			if (fread(&s, sizeof(s), 1, fi) != 1) {
				fprintf(stderr, "Truncated file\n");
				exit(1);
			}
			printf("\t%06x %d", s.s_value, s.s_size);
			switch (s.s_type&S_SEGMASK) {
			case S_ABS: printf(" A"); break;
			case S_TEXT: printf(" T"); break;
			case S_DATA: printf(" D"); break;
			case S_BSS: printf(" B"); break;
			default: printf(" U"); break;
			}
			printf("%c %s\n", (s.s_type&S_UNDEF) ? 'u' : ' ',
				s.s_name);
		}
	}
	if (txt)
		free(txt);
	if (dat)
		free(dat);
	fclose(fi);
}

getbytes(unsigned char *p, int len)
{
	unsigned int v = 0;
	if (len == 1)
		v = p[0];
	else if (len == 2)
		v = p[0] + 256 * p[1];
	else if (len == 3)
		v = p[0] + 256 * p[1] + 65536 * p[2];
	else
		v = -1;
	return v;
}

dumpbytes(unsigned char *p, int len, unsigned int addr)
{
	int n = 0;
	while (n < len) {
		if ((n % 16) == 0)
			printf("\t%06x", addr+n);
		if ((n++ % 8) == 0)
			putchar(' ');
		printf(" %02x", *p++);
		if ((n % 16) == 0)
			putchar('\n');
	}
	if ((n % 16) != 0)
		putchar('\n');
}
