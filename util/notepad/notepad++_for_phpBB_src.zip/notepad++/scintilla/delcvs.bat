del /S /Q .cvsignore
