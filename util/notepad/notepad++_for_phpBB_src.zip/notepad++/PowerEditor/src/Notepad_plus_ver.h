/*
** #define OFFICIAL   1 
** #define FINAL      1 
*/

/****************************************************************************
 *                                                                          *
 *      Notepad_plus_ver.h       -- Version information for internal builds         *
 *                                                                          *
 *      This file is only modified by the official builder to update the         *
 *      VERSION, VER_PRODUCTVERSION and VER_PRODUCTVERSION_STR values            *
 *                                                                          *
 ****************************************************************************/

#ifndef VS_FF_DEBUG 
/* ver.h defines constants needed by the VS_VERSION_INFO structure */
#include <ver.h>
#endif 

/*--------------------------------------------------------------*/
/* the following entry should be phased out in favor of         */
/* VER_PRODUCTVERSION_STR, but is used in the shell today.      */
/*--------------------------------------------------------------*/


/*--------------------------------------------------------------*/
/* the following values should be modified by the official      */
/* builder for each build                                       */
/*--------------------------------------------------------------*/

#define VERSION                     "4.90.205"
#define VER_PRODUCTVERSION_STR      "4.90.205\0"
#define VER_PRODUCTVERSION          4,90,0,205
#define VER_PRODUCTVERSION_DW       (0x04900000 | 205)

#define VER_ORIGINALFILENAME_STR	"Notepad++.exe\0"

#define NOTEPAD_PLUS_VERSION	"Notepad++ v.4.90.205\0"
#define VERSION_VALUE "4.92\0"  // should be X.Y : ie. if VERSION_DIGITALVALUE == 4, 7, 1, 0 , then X = 4, Y = 71 
#define VERSION_DIGITALVALUE 4, 9, 2, 0

#ifndef VER_INTERNALNAME_STR
#define VER_INTERNALNAME_STR	"npp.exe\0"
#endif

/*--------------------------------------------------------------*/
/* the following section defines values used in the version     */
/* data structure for all files, and which do not change.       */
/*--------------------------------------------------------------*/

/* default is nodebug */
#ifndef DEBUG
#define VER_DEBUG                   0
#else
#define VER_DEBUG                   VS_FF_DEBUG
#endif

/* default is privatebuild */
#ifndef OFFICIAL
#define VER_PRIVATEBUILD            VS_FF_PRIVATEBUILD
#else
#define VER_PRIVATEBUILD            0
#endif

/* default is prerelease */
#ifndef FINAL
#define VER_PRERELEASE              VS_FF_PRERELEASE
#else
#define VER_PRERELEASE              0
#endif

#define VER_FILEFLAGSMASK           VS_FFI_FILEFLAGSMASK
#define VER_FILEOS                  VOS_DOS_WINDOWS16
#define VER_FILEFLAGS               (VER_PRIVATEBUILD|VER_PRERELEASE|VER_DEBUG)

#define VER_COMPANYNAME_STR         "Don HO don.h@free.fr\0"
#define VER_PRODUCTNAME_STR         "Notepad++ Customized for phpBB\0"
#define VER_FILEDESCRIPTION_STR     \
"Notepad++ : a free (GNU) source code editor.\0"
#define VER_LEGALTRADEMARKS_STR     \
"Notepad++ : a free (GNU) source code editor.\0"

