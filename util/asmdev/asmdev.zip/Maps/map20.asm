; map20.asm
; sample map20 using NASM and ALINK
; To assemble:
; nasmw -f obj map20.asm -o map20.obj
; alink -oPE -c -dll map20.obj

bits 32

%include "map.inc"   ; include the map

segment code public align=4 flat use32
..start:             ; dll entry point
   mov eax, 1
   ret 12

; DllID: The Dll Identifiction function
; Used by asmdev.exe to identify that this is a valid mapping dll
; Should return 0xBEEF
DllId:
   mov eax, 0xBEEF
   ret

; pc2snes: Define the pc2snes conversion function
; Uses STDCALL convention thus the stack must be restored at the end with a ret 4
pc2snes:

%define PCADDR [esp + 4]

   mov eax, PCADDR
   mov edx, eax
   and eax, 0xFF8000
   shl eax, 1
   or dx, 0x8000
   mov ax, dx

   ret 4


; snes2pc: Defines the snes2pc conversion function
snes2pc:

%define SNADDR [esp + 4]

   mov eax, SNADDR
   mov edx, eax

   shr eax, 16
   cmp al, 0x80
   jl .nodec
   sub al, 0x80
.nodec:
   shr al, 1

   test edx, 0x10000
   jnz .noand
   and edx, 0x7FFF
.noand:
   shl eax, 16
   mov ax, dx

   ret 4