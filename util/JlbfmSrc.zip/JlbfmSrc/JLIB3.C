#include <iosjlib.h>
#include <stdio.h>
#include <dir.h>
#include <dos.h>
#include <windows.h>
#include <io.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>

#define MAJORVER 1              /* \ versiunea 1.3 pentru compatibilitate */
#define MINORVER 3              /* /             */
#define PROGRAM_VERSION "1.3w"  /* versiunea file managerului */
#define BUFFER_SIZE 4096        /* aceasta defineste marimea bufferului temporal */
#define MAXFILES 200            /* numarul maxim de fisiere in librarie */
#define TRUE 1
#define FALSE 0


/*****************************************************/
/*** macrouri pentru definirea mesajelor de eroare ***/
/*****************************************************/
#define ERR_OPEN 1
#define ERR_TEMP 2
#define ERR_LIB_OPEN 3
#define ERR_LIB_BAD 4
#define ERR_LIB_VER 5
#define ERR_NOMEM 6
#define ERR_TOOMANYFILES 7
#define ERR_NOJUNK 8


/****************************************/
/*** valori pentru module de operatii ***/
/****************************************/
#define UNKNOWN -1
#define LIST_FILES 1
#define DIAGNOSTICS 2
#define ADD_FILE 3
#define SUB_FILE 4
#define EXTRACT_FILE 5
#define REMOVE_JUNK 6


/********************************************************/
/*** macrouri pentru decodarea atributelor fisierelor ***/
/********************************************************/
#define ATTR_ARCHIVE(i) (i & 32 ? 'A' : '-')
#define ATTR_READONLY(i) (i & 1 ? 'R' : '-')
#define ATTR_HIDDEN(i) (i & 2 ? 'H' : '-')
#define ATTR_SYSTEM(i) (i & 4 ? 'S' : '-')


/*****************/
/*** structuri ***/
/*****************/
struct header_type {
    char signature[4];
    char majorver, minorver;
    unsigned numfiles;
    unsigned long diroffset;
} JLIB_header;
struct file_info {
    char fileattr;
    struct ftime timedate;
    unsigned long filesize;
    char filename[13];
    unsigned long fileoffset;
} JLIB_directory[MAXFILES];


/*****************/
/*** variabile ***/
/*****************/
int mode = UNKNOWN, quietmode = FALSE, swapthem = FALSE;
char *buffer;
char TempName[13] = {"$$JLIB$$.TMP"}, LibName[80], filename[80];
FILE *LibFP, *TempFP;
struct ffblk findfirstblock;
int nextfile, lastfile, getnew, curpos;
unsigned long HeaderOffset;


/******************/
/*** prototipuri ***/
/******************/
void list_files(void);
void diagnostics(void);
void add_file(char *filename);
void sub_file(char *filename);
void extract_file(char *filename);
void remove_junk(void);
char *fixfilename (char *filename);
char *shortname (char *filename);
char *pathpart (char *filename);
int get_next_external_name(void);
int get_next_internal_name(void);
void handle_error(int errortype);

//����������������������������������������������������������������������������
void main(void)
{
    /*****************************************/
    /*** afisarea de informatii exterioare ***/
    /*****************************************/
    printf("JlibW.exe -- JLib DosStub File Manager, v%s\n", PROGRAM_VERSION);
    printf("by Bodin Florin Ciprian \n");

    /*****************************************/
    /*** determinarea optiunii solicitate  ***/
    /*****************************************/
    if      (_argc >= 3 && strcmp(strupr(_argv[1]), "/V") == 0) mode = LIST_FILES;
    else if (_argc >= 3 && strcmp(strupr(_argv[1]), "/T") == 0) mode = DIAGNOSTICS;
    else if (_argc >= 4 && strcmp(strupr(_argv[1]), "/A") == 0) mode = ADD_FILE;
    else if (_argc >= 4 && strcmp(strupr(_argv[1]), "/D") == 0) mode = SUB_FILE;
    else if (_argc >= 4 && strcmp(strupr(_argv[1]), "/E") == 0) mode = EXTRACT_FILE;
    else if (_argc >= 3 && strcmp(strupr(_argv[1]), "/R") == 0) mode = REMOVE_JUNK;
    if (_argc >= 3) {
        strncpy(LibName, strupr(_argv[2]), 75);
        if (strchr(shortname(LibName), '.') == NULL) strcat(LibName, ".JLB");
    }
    if (_argc >= 4) {
        nextfile = 3; lastfile = _argc;
    } else {
    char  *prompt =  
          "Enter _argc (int): ";
        nextfile = lastfile = 0;
    }
    getnew = TRUE; curpos = 0;


    /************************************/
    /*** afisarea mesajului de ajutor ***/
    /************************************/
    if (mode == UNKNOWN) {
        printf("sintaxa: JlibW /V librarie.ext              (pentru vizualizare)\n");
        printf("         JlibW /T librarie.ext              (diagnosticare)\n");
        printf("         JlibW /A librarie.ext fisier.EXT   (adaugare fisier(e)\n");
        printf("         JlibW /D librarie.ext fisier.EXT   (stergere fisier(e)\n");
        printf("         JlibW /E librarie.ext fisier.EXT   (extragere fisier(e)\n");
        printf("         JlibW /R librarie.ext fisier.EXT   (stergere date junk)\n");
        exit(1);
    }


    /*****************************************************/
    /*** deschiderea librariei si citirea informatiilor ***/
    /*****************************************************/
    printf("Deschid %.12s...", fixfilename(LibName));
    if ((LibFP = fopen(LibName, "rb")) != NULL) {
        int i;

        fseek(LibFP, -1L * sizeof(HeaderOffset), SEEK_END);
        fread(&HeaderOffset, sizeof(HeaderOffset), 1, LibFP);
        HeaderOffset = filelength(fileno(LibFP)) - HeaderOffset;
        fseek(LibFP, HeaderOffset, SEEK_SET);
        fread(&JLIB_header, sizeof(struct header_type), 1, LibFP);
        if (strncmp(JLIB_header.signature, "JLib", 4) != 0) handle_error(ERR_LIB_BAD);
        if (JLIB_header.majorver != MAJORVER || JLIB_header.minorver != MINORVER) handle_error(ERR_LIB_VER);
        fseek(LibFP, HeaderOffset + JLIB_header.diroffset, SEEK_SET);
        for (i = 0; i < JLIB_header.numfiles; i++) {
            fread(&JLIB_directory[i], sizeof(struct file_info), 1, LibFP);
        }
    } else if (mode == ADD_FILE) {
        HeaderOffset = 0;
        if ((LibFP = fopen(LibName, "w+b")) == NULL) handle_error(ERR_LIB_OPEN);
        strncpy(JLIB_header.signature, "JLib", 4);
        JLIB_header.majorver = MAJORVER;
        JLIB_header.minorver = MINORVER;
        JLIB_header.numfiles = 0;
        JLIB_header.diroffset = sizeof(struct header_type);
        fwrite(&JLIB_header, sizeof(struct header_type), 1, LibFP);
    } else {
        printf("\n");
        handle_error(ERR_LIB_OPEN);
    }
    printf("\n");


    /****************************************************************/
    /*** creaza un fisier temporal daca trebuie sa modificam ceva ***/
    /****************************************************************/
    if (mode == ADD_FILE || mode == SUB_FILE) {
        unsigned long copysize, blocksize;

        copysize = filelength(fileno(LibFP));
        fseek(LibFP, 0, SEEK_SET);
        if ((TempFP = fopen(TempName, "w+b")) == NULL) handle_error(ERR_TEMP);
        if ((buffer = malloc(BUFFER_SIZE)) == NULL) handle_error(ERR_NOMEM);

        while (copysize) {
            blocksize = (copysize > BUFFER_SIZE ? BUFFER_SIZE : copysize);
            fread(buffer, sizeof(char), blocksize, LibFP);
            fwrite(buffer, sizeof(char), blocksize, TempFP);
            copysize -= blocksize;
        }

        free(buffer);
    }


    /*************************************************************/
    /*** trecere la codul corect pentru actiunea specificata   ***/
    /*************************************************************/
    switch (mode) {
        case LIST_FILES:
            list_files();
            break;
        case DIAGNOSTICS:
            diagnostics();
            break;
        case ADD_FILE:
            swapthem = TRUE;
            while (get_next_external_name()) add_file(filename);
            break;
        case SUB_FILE:
            swapthem = TRUE;
            while (get_next_internal_name()) {sub_file(filename); curpos--;}
            break;
        case EXTRACT_FILE:
            while (get_next_internal_name()) extract_file(filename);
            break;
        case REMOVE_JUNK:
            remove_junk();
            break;
        default: break;
    }


    /***************************************/
    /*** inchidere biblioteca/executabil ***/
    /***************************************/
    fcloseall();
    if (swapthem) {
        unlink(LibName);
        rename(TempName, LibName);
    } else {
        unlink(TempName);
    }


    /*******************************/
    /*** deactivarea programului ***/
    /*******************************/
    exit(0);
}
//����������������������������������������������������������������������������
void list_files(void)
{
    unsigned i, linecount = 9;
    unsigned long totalsize; 

    printf("Filename     Size       Date       Time     Attr Offset     End\n");
    printf("������������ ���������� ���������� �������� ���� ���������� ����������\n");
    for (i = 0; i < JLIB_header.numfiles; i++, linecount++) {
        printf("%-12.12s %10lu %02.2i-%02.2i-%04.4i %02.2i:%02.2i:%02.2i %c%c%c%c %10lu %10lu\n",
            JLIB_directory[i].filename, JLIB_directory[i].filesize, JLIB_directory[i].timedate.ft_month,
            JLIB_directory[i].timedate.ft_day, JLIB_directory[i].timedate.ft_year + 1980,
            JLIB_directory[i].timedate.ft_hour, JLIB_directory[i].timedate.ft_min,
            JLIB_directory[i].timedate.ft_tsec * 2, ATTR_ARCHIVE(JLIB_directory[i].fileattr),
            ATTR_READONLY(JLIB_directory[i].fileattr), ATTR_HIDDEN(JLIB_directory[i].fileattr),
            ATTR_SYSTEM(JLIB_directory[i].fileattr), JLIB_directory[i].fileoffset,
            JLIB_directory[i].fileoffset+JLIB_directory[i].filesize-1);
        if (linecount % 22 == 0) {
            printf("\nPress any key to continue listing...");
            if (!getch()) getch();
            printf("\n");
        }
    }
    printf("������������ ���������� ���������� �������� ���� ���������� ����������\n");
    if (JLIB_header.numfiles == 0) {
        totalsize = 0;
    } else {
        totalsize = JLIB_directory[JLIB_header.numfiles-1].fileoffset + \
            JLIB_directory[JLIB_header.numfiles-1].filesize - JLIB_header.numfiles * \
            sizeof(struct file_info) - sizeof(struct header_type);
    }
    printf("%12u %10lu\n", JLIB_header.numfiles, totalsize);
}
//����������������������������������������������������������������������������
void diagnostics(void)
{
    char buffer[6];
    unsigned i, errorsfound = 0;
    unsigned long reallength, datalength, lastbyte;


    printf("There are %lu bytes stored before start of library.\n", HeaderOffset);
    lastbyte = sizeof(struct header_type) - 1;
    datalength = sizeof(struct header_type) + JLIB_header.numfiles * sizeof(struct file_info);
    for (i = 0; i < JLIB_header.numfiles; i++) {
        if (lastbyte + 1 != JLIB_directory[i].fileoffset) {
            printf("Gap in data between file \"%.12s\" and previous data\n", JLIB_directory[i].filename);
            errorsfound++;
        }
        lastbyte = JLIB_directory[i].fileoffset + JLIB_directory[i].filesize - 1;
        datalength += JLIB_directory[i].filesize;
    }
    datalength += sizeof(HeaderOffset);
    if (lastbyte + 1 != JLIB_header.diroffset) {
        printf("Gap in data between last file and directory information\n");
        errorsfound++;
    }
    reallength = filelength(fileno(LibFP)) - HeaderOffset;
    if (datalength < reallength) {
        printf("Library is %lu bytes longer than expected.\n", reallength - datalength);
        errorsfound++;
    } else if (datalength > reallength) {
        printf("Library is %lu bytes shorter than expected.\n", datalength - reallength);
        errorsfound++;
    }
    printf("%s error%s detected.\n", (errorsfound ? itoa(errorsfound, \
            buffer, 10) : "No"), (errorsfound != 1 ? "s" : ""));
}
//����������������������������������������������������������������������������
void add_file(char *filename)
{
    FILE *FP;
    unsigned i;
    char *buffer;
    unsigned long copysize, blocksize, ourlength;


    /**************************************************/
    /*** daca fisierul exista deja fa reactualizare ***/
    /**************************************************/
    for (i = 0; i < JLIB_header.numfiles; i++) {
        if (strncmp(JLIB_directory[i].filename, fixfilename(filename), 13) == 0) {
            printf("updating %s...", fixfilename(filename));
            quietmode = TRUE;
            sub_file(filename);
            add_file(filename);
            quietmode = FALSE;
            printf("gata\n");
            return;
        }
    }


    /************************/
    /*** deschide fisirul ***/
    /************************/
    if (!quietmode) printf("adaug %s...", fixfilename(filename));
    if ((FP = fopen(filename, "rb")) == NULL) {
        printf("Nu pot deschide\n", filename);
        return;
    }


    /*******************************************/
    /*** seteaza struructura noului fisier   ***/
    /*******************************************/
    i = JLIB_header.numfiles;
    JLIB_header.numfiles++;
    if (JLIB_header.numfiles > MAXFILES) handle_error(ERR_TOOMANYFILES);
    strncpy(JLIB_directory[i].filename, fixfilename(filename), 12);
    JLIB_directory[i].filesize = filelength(fileno(FP));
    JLIB_directory[i].fileattr = 0;
    getftime(fileno(FP), &JLIB_directory[i].timedate);
    if (i != 0) {
        JLIB_directory[i].fileoffset = JLIB_directory[i-1].fileoffset + JLIB_directory[i-1].filesize;
    } else {
        JLIB_directory[i].fileoffset = sizeof(struct header_type);
    }
    JLIB_header.diroffset += JLIB_directory[i].filesize;


    /******************************/
    /*** scrie un "heder" nou   ***/
    /******************************/
    fseek(TempFP, HeaderOffset, SEEK_SET);
    fwrite(&JLIB_header, sizeof(struct header_type), 1, TempFP);


    /*********************************************/
    /*** copie peste fisierul vechi...         ***/
    /*********************************************/
    if ((buffer = malloc(BUFFER_SIZE)) == NULL) handle_error(ERR_NOMEM);
    fseek(TempFP, HeaderOffset+JLIB_directory[i].fileoffset, SEEK_SET);
    copysize = filelength(fileno(FP));
    fseek(FP, 0, SEEK_SET);
    while (copysize) {
        blocksize = (copysize > BUFFER_SIZE ? BUFFER_SIZE : copysize);
        fread(buffer, sizeof(char), blocksize, FP);
        fwrite(buffer, sizeof(char), blocksize, TempFP);
        copysize -= blocksize;
        if (!quietmode) printf(".");
    }
    free(buffer);


    /************************************************************/
    /*** scrie structura noului director (dos)                ***/
    /************************************************************/
    fseek(TempFP, HeaderOffset+JLIB_header.diroffset, SEEK_SET);
    fwrite(JLIB_directory, sizeof(struct file_info), JLIB_header.numfiles, TempFP);

    
    /*********************************************/
    /*** scrie "pointerul" nostru si sfarsitul ***/
    /*********************************************/
    fseek(TempFP, HeaderOffset+JLIB_header.diroffset + JLIB_header.numfiles * \
            sizeof(struct file_info), SEEK_SET);
    ourlength = sizeof(ourlength) + ftell(TempFP) - HeaderOffset;
    fwrite(&ourlength, sizeof(ourlength), 1, TempFP);
    chsize(fileno(TempFP), ourlength + HeaderOffset);

    fclose(FP);
    if (!quietmode) printf("gata\n");
}
//����������������������������������������������������������������������������
void sub_file(char *filename)
{
    char *buffer;
    unsigned i, entrynumber, found = FALSE;
    unsigned long copysize, blocksize, sourcepos, targetpos, filesize, ourlength;


    /********************************************/
    /*** verifica daca fisierul exista        ***/
    /********************************************/
    if (!quietmode) printf("sterg fisierul %s...", fixfilename(filename));
    for (i = 0; i < JLIB_header.numfiles; i++) {
        if (strncmp(JLIB_directory[i].filename, fixfilename(filename), 13) == 0) {
            found = TRUE;
            entrynumber = i;
            break;
        }
    }
    if (!found) {
        printf("Eroare: fisierul nu e in librarie\n");
        return;
    }


    /******************************/
    /*** scrie un "header" nou  ***/
    /******************************/
    JLIB_header.numfiles--;
    JLIB_header.diroffset -= JLIB_directory[entrynumber].filesize;
    fseek(TempFP, HeaderOffset, SEEK_SET);
    fwrite(&JLIB_header, sizeof(char), sizeof(struct header_type), TempFP);
    JLIB_header.numfiles++;     /* doar momentan (fixeaza mai tarziu) */


    /*************************************************************/
    /*** calculeaza marimea dupa ce fisierul trebuie mutat     ***/
    /*************************************************************/
    copysize = 0;
    for (i = entrynumber + 1; i < JLIB_header.numfiles; i++) {
        copysize += JLIB_directory[i].filesize;
    }
    sourcepos = HeaderOffset + JLIB_directory[entrynumber+1].fileoffset;
    targetpos = HeaderOffset + JLIB_directory[entrynumber].fileoffset;


    /**************************/
    /*** muta datele...     ***/
    /**************************/
    if ((buffer = malloc(BUFFER_SIZE)) == NULL) handle_error(ERR_NOMEM);
    while (copysize) {
        blocksize = (copysize > BUFFER_SIZE ? BUFFER_SIZE : copysize);
        fseek(TempFP, sourcepos, SEEK_SET);
        fread(buffer, sizeof(char), blocksize, TempFP);
        fseek(TempFP, targetpos, SEEK_SET);
        fwrite(buffer, sizeof(char), blocksize, TempFP);
        copysize -= blocksize;
        sourcepos += blocksize;
        targetpos += blocksize;
        if (!quietmode) printf(".");
    }
    free(buffer);


    /**************************************************************************/
    /*** reactualizeaza structura directorului pentru a reflecta schimbarea ***/
    /**************************************************************************/
    filesize = JLIB_directory[entrynumber].filesize;
    for (i = entrynumber + 1; i < JLIB_header.numfiles; i++) {
        JLIB_directory[i - 1] = JLIB_directory[i];
        JLIB_directory[i - 1].fileoffset -= filesize;
    }
    JLIB_header.numfiles--;     /* restaurarea heder-ului */


    /*************************************************/
    /*** srie noua structura interna de directoare ***/
    /*************************************************/
    fseek(TempFP, HeaderOffset + JLIB_header.diroffset, SEEK_SET);
    fwrite(JLIB_directory, sizeof(struct file_info), JLIB_header.numfiles, TempFP);


    /****************************************************/
    /*** srie noul poiter si sterge orce date in plus ***/
    /****************************************************/
    fseek(TempFP, HeaderOffset+JLIB_header.diroffset + JLIB_header.numfiles * \
            sizeof(struct file_info), SEEK_SET);
    ourlength = sizeof(ourlength) + ftell(TempFP) - HeaderOffset;
    fwrite(&ourlength, sizeof(ourlength), 1, TempFP);
    chsize(fileno(TempFP), ourlength + HeaderOffset);

    if (!quietmode) printf("gata\n");
}
//����������������������������������������������������������������������������
void extract_file(char *filename)
{
    unsigned i, entrynumber, found = FALSE;
    char *buffer;
    FILE *FP;
    unsigned long copysize, blocksize;


    /*********************************************/
    /*** verifica srierea corecta a fisierului ***/
    /*********************************************/
    if (!quietmode) printf("extrag %s...", fixfilename(filename));
    for (i = 0; i < JLIB_header.numfiles; i++) {
        if (strncmp(JLIB_directory[i].filename, fixfilename(filename), 13) == 0) {
            found = TRUE;
            entrynumber = i;
            break;
        }
    }
    if (!found) {
        printf("Eroare-fisierul nu e in librarie\n");
        return;
    }


    /******************************************************/
    /*** deschide fisierul si scrie in exterior datele  ***/
    /******************************************************/
    if ((buffer = malloc(BUFFER_SIZE)) == NULL) handle_error(ERR_NOMEM);
    if ((FP = fopen(filename, "w+b")) == NULL) {
        printf("Eroare deschizand fisierul.\n");
        return;
    }
    fseek(LibFP, HeaderOffset + JLIB_directory[entrynumber].fileoffset, SEEK_SET);
    copysize = JLIB_directory[entrynumber].filesize;
    while (copysize) {
        blocksize = (copysize > BUFFER_SIZE ? BUFFER_SIZE : copysize);
        fread(buffer, sizeof(char), blocksize, LibFP);
        fwrite(buffer, sizeof(char), blocksize, FP);
        copysize -= blocksize;
        if (!quietmode) printf(".");
    }
    fclose(FP);
    free(buffer);
    if (!quietmode) printf("gata\n");
}
//����������������������������������������������������������������������������
void remove_junk(void)
{
    char *buffer;
    unsigned long copysize, blocksize;

    if (HeaderOffset == 0) handle_error(ERR_NOJUNK);
    if ((buffer = malloc(BUFFER_SIZE)) == NULL) handle_error(ERR_NOMEM);
    if ((TempFP = fopen(TempName, "w+b")) == NULL) handle_error(ERR_TEMP);
    printf("sterg/mut %lu biti de date junk...", HeaderOffset);
    fseek(LibFP, HeaderOffset, SEEK_SET);
    copysize = filelength(fileno(LibFP)) - HeaderOffset;
    while (copysize) {
        blocksize = (copysize > BUFFER_SIZE ? BUFFER_SIZE : copysize);
        fread(buffer, sizeof(char), blocksize, LibFP);
        fwrite(buffer, sizeof(char), blocksize, TempFP);
        copysize -= blocksize;
        printf(".");
    }
    fclose(LibFP); fclose(TempFP);
    unlink(LibName);
    rename(TempName, LibName);
    free(buffer);
    printf("\n");
}
//����������������������������������������������������������������������������
char *fixfilename (char *filename)
{
    int i, j;
    char *p, buffer[80];

    // scrie identificatorul unitatii de disc
    if ((p = strrchr(filename, '\\')) != NULL) {
        strncpy(buffer, strupr(p + 1), 80);
    } else if ((p = strrchr(filename, ':')) != NULL) {
        strncpy(buffer, strupr(p + 1), 80);
    } else {
        strncpy(buffer, strupr(filename), 80);
    }

    // scoate orice caracter in plus dupa astericks
    for (i = 0; i < strlen(buffer); i++) {
        if (buffer[i] == '*') {
            for (j = i + 1; j < strlen(buffer); j++) {
                if (buffer[j] == '.' || buffer[j] == 0) break;
            }
            if (j > i + 1) strcpy(&buffer[i+1], &buffer[j]);
        }
    }

    // asigurate ca in interior este o perioada
    if ((p = strrchr(buffer, '.')) == NULL) {
        j = '.'; strcat(buffer, (char *) &j);
    }

    // limiteaza lungimea fisierului la 8.3
    for (i = 0, j = 0; i < strlen(buffer); i++, j++) {
        if (buffer[i] == '.') {
            if (j > 8) strcpy(&buffer[8], &buffer[i]);
            break;
        }
    }
    *(strchr(buffer, '.')+4) = 0;

    return(buffer);
}
//����������������������������������������������������������������������������
char *shortname (char *filename)
{
    char *p;

    if ((p = strrchr(filename, '\\')) != NULL) {
        return(strupr(p + 1));
    } else if ((p = strrchr(filename, ':')) != NULL) {
        return(strupr(p + 1));
    } else {
        return(strupr(filename));
    }
}
//����������������������������������������������������������������������������
char *pathpart (char *filename)
{
    char *p;
    char buffer[80];

    strncpy(buffer, filename, 80);
    if ((p = strrchr(buffer, '\\')) != NULL) {
        *(p+1) = 0;
    } else if ((p = strrchr(filename, ':')) != NULL) {
        *(p+1) = 0;
    } else {
        buffer[0] = 0;
    }
    return(buffer);
}
//����������������������������������������������������������������������������
int get_next_external_name(void)
{
    int gata;

    while (TRUE) {
        if (getnew) {
            if (nextfile >= lastfile) return(FALSE);
            gata = findfirst(_argv[nextfile], &findfirstblock, 0);
            getnew = FALSE;
        } else {
            gata = findnext(&findfirstblock);
        }
        if (gata) {
            nextfile++;
            getnew = TRUE;
        } else {
            strcpy(filename, pathpart(_argv[nextfile]));
            strcat(filename, findfirstblock.ff_name);
            if (strncmp(filename, fixfilename(LibName), 13) != 0 &&
                strncmp(filename, TempName, 13) != 0) return(TRUE);
        }
    }
}
//����������������������������������������������������������������������������
int get_next_internal_name(void)
{
    int match, i, pointer1, pointer2;
    char wildcard[13];

    while (TRUE) {
        if (nextfile >= lastfile) return(FALSE);
        for (; curpos < JLIB_header.numfiles; curpos++) {
            strcpy(wildcard, fixfilename(_argv[nextfile]));
            pointer1 = pointer2 = 0; match = UNKNOWN;
            while (match == UNKNOWN && pointer1 <= strlen(wildcard) && \
                    pointer2 <= strlen(JLIB_directory[curpos].filename)) {
                switch (wildcard[pointer1]) {
                    case 0:
                        if (JLIB_directory[curpos].filename[pointer2] == 0) {
                            match = TRUE;
                        } else {
                            match = FALSE;
                        }
                        break;
                    case '*':
                        if (JLIB_directory[curpos].filename[pointer2] == '.' ||
                                JLIB_directory[curpos].filename[pointer2] == 0) {
                            pointer1++;
                        } else {
                            pointer2++;
                        }
                        break;
                    case '?':
                        pointer1++; pointer2++;
                        break;
                    default:
                        if (wildcard[pointer1] != JLIB_directory[curpos].filename[pointer2]) {
                            match = FALSE;
                        } else {
                            pointer1++; pointer2++;
                        }
                        break;
                }
            }
            if (match == TRUE) {
                strcpy(filename, JLIB_directory[curpos].filename);
                curpos++;
                return(TRUE);
            }
        }
        nextfile++; curpos = 0;
    }
}
//����������������������������������������������������������������������������
void handle_error(int errortype)
{
    fcloseall();
    printf("***Eroare*** ");
    switch (errortype) {
        case ERR_OPEN: printf("Nu pot deschide fisierul\n"); break;
        case ERR_TEMP: printf("Nu pot creia fisierul temporal\n"); break;
        case ERR_LIB_OPEN: printf("Nu pot deschide libraria\n"); break;
        case ERR_LIB_BAD: printf("Fisier nesuportat\n"); break;
        case ERR_LIB_VER: printf("Alta versiune de librarie\n"); break;
        case ERR_NOMEM: printf("Memorie insuficienta\n"); break;
        case ERR_TOOMANYFILES: printf("Prea multe fisiere in librarie\n"); break;
        case ERR_NOJUNK: printf("Date junk inexistente\n"); break;
        default: printf("Eroare necunoscuta\n"); break;
    }
    exit(errortype);
}
//����������������������������������������������������������������������������
