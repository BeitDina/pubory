#include <stdio.h>
#include <dos.h>
#include <conio.h>
int but,x,y;
void main()
{	asm{	push	ax
		xor	ax,ax
		int	33h
		mov	but,ax
		pop	ax}
	if(but!=-1)
	{	printf("No mouse driver is installed\r\n");
		exit(-1);}
	_setcursortype(_NOCURSOR);
	while(!kbhit())
	{	asm{    push	ax bx cx dx
			mov	ax,3
			int	33h
			mov	but,bx
			mov	x,cx
			mov	y,dx
			pop	dx cx bx ax}
		printf("\rx=%i, y=%i",x,y);
		if(but){printf(", buttons: ");
			if(but&1)	printf("left ");
			if(but&2)	printf("right ");
			if(but&4)	printf("middle ");
			if(but&8)	printf("middle2");}
		printf("                          ");}
	if(getch()==0)	getch();
	printf("\r\n");
}