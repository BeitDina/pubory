3D Editor, v1.01 by Albu Cristian, e-mail: hlt@mechazombie.com

3D Editor is a text editor for programmers
- has a scripting language for compiler configuration
- can edit text/binary files of any size
- can generate arrays for ASM/C/C++/Pascal/Basic
- has configurable visual effects
- supports NTFS Streams, can create hard links
- can generate HTML index for directories