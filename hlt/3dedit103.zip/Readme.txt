
3D Editor, v1.0.3.6000 by Albu Cristian, e-mail: hlt3000@yahoo.com

3D Editor is a text editor for programmers
- has a scripting language for compiler configuration
- can edit text/binary files of any size
- has configurable visual effects
- supports NTFS Streams, can create hard links
- can generate HTML index for directories
- custom help file support with topic search
- contains Microsoft Windows error codes
- has array generators for ASM/C++/Basic/Delphi