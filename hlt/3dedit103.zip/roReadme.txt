
3D Editor, v1.0.3.6000 by Albu Cristian, e-mail: hlt3000@yahoo.com

	3D Editor este un editor de text pentru programatori
	 - poate �nc�rca fi�iere text/binare de orice m�rime
	 - are efecte vizuale configurabile
	 - suport� stream-uri �n NTFS
	 - poate genera un index HTML ce con�ine structura unui director
	 - configurarea unui compilator se face cu ajutorul unui script
	 - suport� fi�iere help definite de utilizator
	 - con�ine codurile de eroare Microsoft Windows
	 - poate genera matrici pentru ASM/C++/Basic/Delphi
