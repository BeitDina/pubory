Dim Ask, WSHShell, MyShortcut, MyDesktop, DesktopPath, FileSys, FName
																
Ask = msgbox ("Would you like to have a shortcut to 3D Editor on your desktop?", vbokcancel, "3D Editor")
If Ask = vbCancel Then
	WScript.Quit
End If

set FileSys = CreateObject ("scripting.FileSystemObject")
set FName = FileSys.Getfile (Wscript.Scriptname)
FName = Left(FName, Len(FName) - 12)

Set WSHShell = WScript.CreateObject("WScript.Shell")
DesktopPath = WSHShell.SpecialFolders("Desktop")
Set MyShortcut = WSHShell.CreateShortcut(DesktopPath & "\3D Editor.lnk")

MyShortcut.TargetPath = FName & "3dedit.exe"
MyShortcut.WorkingDirectory = FName
MyShortcut.WindowStyle = 4
MyShortcut.IconLocation = FName & "3dedit.exe"
MyShortcut.Save

MsgBox "A shortcut to 3D Editor is now on your Desktop", vbinformation, "Done"